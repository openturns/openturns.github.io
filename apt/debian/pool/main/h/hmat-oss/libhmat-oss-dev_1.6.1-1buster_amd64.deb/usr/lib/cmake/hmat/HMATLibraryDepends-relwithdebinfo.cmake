#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hmat-oss" for configuration "RelWithDebInfo"
set_property(TARGET hmat-oss APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(hmat-oss PROPERTIES
  IMPORTED_LINK_INTERFACE_LIBRARIES_RELWITHDEBINFO "rt;m"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libhmat-oss.so.1.6.1"
  IMPORTED_SONAME_RELWITHDEBINFO "libhmat-oss.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS hmat-oss )
list(APPEND _IMPORT_CHECK_FILES_FOR_hmat-oss "${_IMPORT_PREFIX}/lib/libhmat-oss.so.1.6.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

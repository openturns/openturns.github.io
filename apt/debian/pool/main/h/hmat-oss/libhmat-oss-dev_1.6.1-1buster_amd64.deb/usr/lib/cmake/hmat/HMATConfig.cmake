#  HMat-OSS (HMatrix library, open source software)
#
#  Copyright (C) 2014-2015 Airbus Group SAS
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
#  http://github.com/jeromerobert/hmat-oss

# - Config file for the HMAT package
# It defines the following variables
#  HMAT_INCLUDE_DIRS - include directories for HMAT
#  HMAT_LIBRARY_DIRS - library directories for HMAT (normally not used!)
#  HMAT_LIBRARIES    - libraries to link against
#  HMAT_EXECUTABLE   - the bar executable
#  HMAT_DEFINITIONS  - List of compilation flags -DTOTO to export

# defined since 2.8.3
if(CMAKE_VERSION VERSION_LESS 2.8.3)
  get_filename_component (CMAKE_CURRENT_LIST_DIR ${CMAKE_CURRENT_LIST_FILE} PATH)
endif ()

# Tell the user project where to find our headers and libraries

set(HMAT_INCLUDE_DIRS "${CMAKE_CURRENT_LIST_DIR}/../../../include/hmat;")
set(HMAT_LIBRARY_DIRS "${CMAKE_CURRENT_LIST_DIR}/../../")

# Allows loading HMAT settings from another project
set(HMAT_CONFIG_FILE "${CMAKE_CURRENT_LIST_FILE}")

# List of compilation flags -DTOTO to export
set(HMAT_DEFINITIONS "")

# Our library dependencies (contains definitions for IMPORTED targets)
include("${CMAKE_CURRENT_LIST_DIR}/HMATLibraryDepends.cmake")

# These are IMPORTED targets created by HMATLibraryDepends.cmake
set(HMAT_LIBRARIES "hmat-oss")

if(CMAKE_VERSION VERSION_LESS 2.8.3)
  set(CMAKE_CURRENT_LIST_DIR)
endif ()

#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "HMAT::hmat" for configuration "None"
set_property(TARGET HMAT::hmat APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(HMAT::hmat PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libhmat.so.1.8.1"
  IMPORTED_SONAME_NONE "libhmat.so.3"
  )

list(APPEND _IMPORT_CHECK_TARGETS HMAT::hmat )
list(APPEND _IMPORT_CHECK_FILES_FOR_HMAT::hmat "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libhmat.so.1.8.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

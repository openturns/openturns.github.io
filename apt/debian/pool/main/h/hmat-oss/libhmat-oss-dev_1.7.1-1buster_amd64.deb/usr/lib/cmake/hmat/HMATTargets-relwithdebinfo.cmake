#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "HMAT::hmat" for configuration "RelWithDebInfo"
set_property(TARGET HMAT::hmat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(HMAT::hmat PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libhmat.so.1.7.1"
  IMPORTED_SONAME_RELWITHDEBINFO "libhmat.so.2"
  )

list(APPEND _IMPORT_CHECK_TARGETS HMAT::hmat )
list(APPEND _IMPORT_CHECK_FILES_FOR_HMAT::hmat "${_IMPORT_PREFIX}/lib/libhmat.so.1.7.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

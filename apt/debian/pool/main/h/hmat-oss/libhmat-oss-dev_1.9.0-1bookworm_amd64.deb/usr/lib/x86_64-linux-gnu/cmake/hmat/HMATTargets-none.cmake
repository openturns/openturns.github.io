#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "HMAT::hmat" for configuration "None"
set_property(TARGET HMAT::hmat APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(HMAT::hmat PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libhmat.so.1.9.0"
  IMPORTED_SONAME_NONE "libhmat.so.4"
  )

list(APPEND _cmake_import_check_targets HMAT::hmat )
list(APPEND _cmake_import_check_files_for_HMAT::hmat "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libhmat.so.1.9.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

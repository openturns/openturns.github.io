#                                               -*- cmake -*-
#
#  OTPMMLConfig.cmake(.in)
#
#  Find OTPMML includes and libraries
#
#  Copyright (C) 2005-2014 Phimeca
#

# Use the following variables to compile and link against OTPMML:
#  OTPMML_FOUND          - True if OTPMML was found on your system
#  OTPMML_USE_FILE       - The file making OTPMML usable
#  OTPMML_DEFINITIONS    - Definitions needed to build with OTPMML
#  OTPMML_INCLUDE_DIRS   - List of directories where OTPMML' header file are
#  OTPMML_LIBRARY        - Library name
#  OTPMML_LIBRARIES      - List of libraries to link against
#  OTPMML_LIBRARY_DIRS   - List of directories containing OTPMML' libraries
#  OTPMML_ROOT_DIR       - The base directory of OTPMML
#  OTPMML_VERSION_STRING - A human-readable string containing the version
#  OTPMML_VERSION_MAJOR  - The major version of OTPMML
#  OTPMML_VERSION_MINOR  - The minor version of OTPMML
#  OTPMML_VERSION_PATCH  - The patch version of OTPMML

set ( OTPMML_FOUND 1 )
set ( OTPMML_USE_FILE     "/usr/lib/cmake/otpmml/UseOTPMML.cmake" )

set ( OTPMML_DEFINITIONS  "" )
set ( OTPMML_INCLUDE_DIR  "/usr/include" )
set ( OTPMML_INCLUDE_DIRS "/usr/include;/usr/include" )
set ( OTPMML_LIBRARY      "otpmml" )
set ( OTPMML_LIBRARIES    "-lpthread;OT;otpmml" )
set ( OTPMML_LIBRARY_DIRS "/usr/lib/x86_64-linux-gnu;/usr/lib" )
set ( OTPMML_ROOT_DIR     "/usr" )

set ( OTPMML_VERSION_STRING "1.12" )
set ( OTPMML_VERSION_MAJOR  "1" )
set ( OTPMML_VERSION_MINOR  "12" )
set ( OTPMML_VERSION_PATCH  "" )

set (OTPMML_PYTHON3_MODULE_PATH "/usr/lib/python3.9/site-packages")

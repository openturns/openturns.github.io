.. image:: https://github.com/openturns/otagrum/actions/workflows/build.yml/badge.svg?branch=master
    :target: https://github.com/openturns/otagrum/actions/workflows/build.yml

otagrum Module
==============

otagrum is a module for mixing OpenTURNS and aGrUM

More information can found at http://www.openturns.org and http://agrum.gitlab.io


Installation
============
Please see the http://openturns.github.io/openturns/latest/install.html
for instructions on installing OpenTURNS modules on various platforms from binaries or sources.

-- The OpenTURNS/pyAgrum team

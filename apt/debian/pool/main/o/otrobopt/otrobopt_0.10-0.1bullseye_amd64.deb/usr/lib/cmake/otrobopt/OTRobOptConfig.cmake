#                                               -*- cmake -*-
#
#  OTRobOptConfig.cmake(.in)
#
#  Find OTRobOpt includes and libraries
#
#  Copyright 2005-2018 Phimeca
#

# Use the following variables to compile and link against OTRobOpt:
#  OTROBOPT_FOUND          - True if OTRobOpt was found on your system
#  OTROBOPT_USE_FILE       - The file making OTRobOpt usable
#  OTROBOPT_DEFINITIONS    - Definitions needed to build with OTRobOpt
#  OTROBOPT_INCLUDE_DIRS   - List of directories where OTRobOpt' header file are
#  OTROBOPT_LIBRARY        - Library name
#  OTROBOPT_LIBRARIES      - List of libraries to link against
#  OTROBOPT_LIBRARY_DIRS   - List of directories containing OTRobOpt' libraries
#  OTROBOPT_ROOT_DIR       - The base directory of OTRobOpt
#  OTROBOPT_VERSION_STRING - A human-readable string containing the version
#  OTROBOPT_VERSION_MAJOR  - The major version of OTRobOpt
#  OTROBOPT_VERSION_MINOR  - The minor version of OTRobOpt
#  OTROBOPT_VERSION_PATCH  - The patch version of OTRobOpt

set ( OTROBOPT_FOUND 1 )
set ( OTROBOPT_USE_FILE     "/usr/lib/cmake/otrobopt/UseOTRobOpt.cmake" )

set ( OTROBOPT_DEFINITIONS  "" )
set ( OTROBOPT_INCLUDE_DIR  "/usr/include" )
set ( OTROBOPT_INCLUDE_DIRS "/usr/include;/usr/include;/usr/include" )
set ( OTROBOPT_LIBRARY      "otrobopt" )
set ( OTROBOPT_LIBRARIES    "/usr/lib/x86_64-linux-gnu/libtbb.so;-lpthread;OT;otrobopt" )
set ( OTROBOPT_LIBRARY_DIRS "/usr/lib;/usr/lib" )
set ( OTROBOPT_ROOT_DIR     "/usr" )

set ( OTROBOPT_VERSION_STRING "0.10" )
set ( OTROBOPT_VERSION_MAJOR  "0" )
set ( OTROBOPT_VERSION_MINOR  "10" )
set ( OTROBOPT_VERSION_PATCH  "" )

set (OTROBOPT_PYTHON3_MODULE_PATH "/usr/lib/python3.9/site-packages")

# CMAKE_CURRENT_LIST_DIR defined since 2.8.3
if (CMAKE_VERSION VERSION_LESS 2.8.3)
  get_filename_component (CMAKE_CURRENT_LIST_DIR ${CMAKE_CURRENT_LIST_FILE} PATH)
endif ()
# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/OTRobOpt-Targets.cmake)

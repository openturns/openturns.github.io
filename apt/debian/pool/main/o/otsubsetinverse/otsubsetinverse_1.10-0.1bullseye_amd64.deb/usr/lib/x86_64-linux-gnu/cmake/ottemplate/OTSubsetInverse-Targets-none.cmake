#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otsubsetinverse" for configuration "None"
set_property(TARGET otsubsetinverse APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(otsubsetinverse PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotsubsetinverse.so.0.0.0"
  IMPORTED_SONAME_NONE "libotsubsetinverse.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otsubsetinverse )
list(APPEND _IMPORT_CHECK_FILES_FOR_otsubsetinverse "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotsubsetinverse.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

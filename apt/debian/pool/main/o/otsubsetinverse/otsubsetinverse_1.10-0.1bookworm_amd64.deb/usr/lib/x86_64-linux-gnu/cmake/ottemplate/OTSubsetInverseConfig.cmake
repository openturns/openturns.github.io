#                                               -*- cmake -*-
#
#  OTSubsetInverseConfig.cmake(.in)
#
#  Find OTSubsetInverse includes and libraries
#
#  Copyright (C) 2005-2014 Phimeca
#

# Use the following variables to compile and link against OTSubsetInverse:
#  OTSUBSETINVERSE_FOUND          - True if OTSubsetInverse was found on your system
#  OTSUBSETINVERSE_DEFINITIONS    - Definitions needed to build with OTSubsetInverse
#  OTSUBSETINVERSE_INCLUDE_DIRS   - List of directories where OTSubsetInverse' header file are
#  OTSUBSETINVERSE_LIBRARY        - Library name
#  OTSUBSETINVERSE_LIBRARIES      - List of libraries to link against
#  OTSUBSETINVERSE_LIBRARY_DIRS   - List of directories containing OTSubsetInverse' libraries
#  OTSUBSETINVERSE_ROOT_DIR       - The base directory of OTSubsetInverse
#  OTSUBSETINVERSE_VERSION_STRING - A human-readable string containing the version
#  OTSUBSETINVERSE_VERSION_MAJOR  - The major version of OTSubsetInverse
#  OTSUBSETINVERSE_VERSION_MINOR  - The minor version of OTSubsetInverse
#  OTSUBSETINVERSE_VERSION_PATCH  - The patch version of OTSubsetInverse

set ( OTSUBSETINVERSE_FOUND 1 )

set ( OTSUBSETINVERSE_DEFINITIONS  "" )
set ( OTSUBSETINVERSE_INCLUDE_DIR  "/usr/include" )
set ( OTSUBSETINVERSE_INCLUDE_DIRS "/usr/include;/usr/include" )
set ( OTSUBSETINVERSE_LIBRARY      "ottemplate" )
set ( OTSUBSETINVERSE_LIBRARIES    "OT;ottemplate" )
set ( OTSUBSETINVERSE_LIBRARY_DIRS "/usr/lib/x86_64-linux-gnu;/usr/lib/x86_64-linux-gnu" )
set ( OTSUBSETINVERSE_ROOT_DIR     "/usr" )

set ( OTSUBSETINVERSE_VERSION_STRING "1.10" )
set ( OTSUBSETINVERSE_VERSION_MAJOR  "1" )
set ( OTSUBSETINVERSE_VERSION_MINOR  "10" )
set ( OTSUBSETINVERSE_VERSION_PATCH  "" )

set (OTSUBSETINVERSE_PYTHON_MODULE_PATH "/usr/lib/python3.11/site-packages")

# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/OTSubsetInverse-Targets.cmake)

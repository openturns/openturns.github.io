#                                               -*- cmake -*-
#
#  otmixmodConfig.cmake(.in)
#
#  Find otmixmod includes and libraries
#
#  (C) Copyright 2008-2013 Phimeca
#

# Use the following variables to compile and link against otmixmod:
#  OTMIXMOD_FOUND          True if otmixmod was found on your system
#  OTMIXMOD_DEFINITIONS    Definitions needed to build with otmixmod
#  OTMIXMOD_INCLUDE_DIRS   List of directories where otmixmod' header file are
#  OTMIXMOD_LIBRARIES      List of libraries to link against
#  OTMIXMOD_LIBRARY_DIRS   List of directories containing otmixmod' libraries
#  OTMIXMOD_ROOT_DIR       The base directory of otmixmod
#  OTMIXMOD_VERSION_STRING A human-readable string containing the version
#  OTMIXMOD_VERSION_MAJOR  The major version of otmixmod
#  OTMIXMOD_VERSION_MINOR  The minor version of otmixmod
#  OTMIXMOD_VERSION_PATCH  The patch version of otmixmod

set ( OTMIXMOD_FOUND 1 )

set ( OTMIXMOD_DEFINITIONS  "" )
set ( OTMIXMOD_INCLUDE_DIR  "/usr/include" )
set ( OTMIXMOD_INCLUDE_DIRS "/usr/include;/usr/include" )
set ( OTMIXMOD_LIBRARIES    "OT;otmixmod" )
set ( OTMIXMOD_LIBRARY_DIRS "/usr/lib/x86_64-linux-gnu;/usr/lib/x86_64-linux-gnu" )
set ( OTMIXMOD_ROOT_DIR     "/usr" )

set ( OTMIXMOD_VERSION_STRING "0.14" )
set ( OTMIXMOD_VERSION_MAJOR  "0" )
set ( OTMIXMOD_VERSION_MINOR  "14" )
set ( OTMIXMOD_VERSION_PATCH  "" )

set (OTMIXMOD_PYTHON_MODULE_PATH "lib/python3.9/site-packages")

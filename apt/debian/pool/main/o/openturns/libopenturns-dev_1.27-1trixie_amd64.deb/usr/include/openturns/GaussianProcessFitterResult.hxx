//                                               -*- C++ -*-
/**
 *  @brief The result of a gaussian process fitter
 *
 *  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
#ifndef OPENTURNS_GAUSSIANPROCESSFITTERRESULT_HXX
#define OPENTURNS_GAUSSIANPROCESSFITTERRESULT_HXX

#include "openturns/MetaModelResult.hxx"
#include "openturns/CovarianceModel.hxx"
#include "openturns/Sample.hxx"
#include "openturns/PersistentCollection.hxx"
#include "openturns/Basis.hxx"
#include "openturns/Function.hxx"
#include "openturns/GaussianProcess.hxx"
#include "openturns/HMatrix.hxx"

BEGIN_NAMESPACE_OPENTURNS

/**
 * @class GaussianProcessFitterResult
 *
 * The result of a gaussian process fitter
 */

class OT_API GaussianProcessFitterResult
  : public MetaModelResult
{
  CLASSNAME

public:

  enum LinearAlgebra { LAPACK, HMAT };

  typedef Collection<Point> PointCollection;
  typedef PersistentCollection<Point> PointPersistentCollection;
  typedef Collection<CovarianceMatrix> CovarianceMatrixCollection;

  /** Default constructor */
  GaussianProcessFitterResult();

  /** Parameter constructor after a gaussian process fitting  */
  GaussianProcessFitterResult(const Sample & inputData,
                              const Sample & outputData,
                              const Function & metaModel,
                              const Matrix & regressionMatrix,
                              const Basis & basis,
                              const Point & trendCoefficients,
                              const CovarianceModel & covarianceModel,
                              const Scalar optimalLogLikelihood,
                              const LinearAlgebra linearAlgebraMethod);

  /** Virtual constructor */
  GaussianProcessFitterResult * clone() const override;

  /** String converter */
  String __repr__() const override;
  String __str__(const String & offset = "") const override;

  /** Trend basis accessor */
  Basis getBasis() const;

  /** Trend coefficients accessor */
  Point getTrendCoefficients() const;

  /** Conditional covariance models accessor */
  CovarianceModel getCovarianceModel() const;

  /** optimal log-likelihood value */
  Scalar getOptimalLogLikelihood() const;

  /** linear algebra method */
  LinearAlgebra getLinearAlgebraMethod() const;

  /** Regression matrix accessor */
  Matrix getRegressionMatrix() const;

  /** process accessor */
  GaussianProcess getCenteredProcess() const;

  /** Output sample noise accessor */
  void setNoise(const CovarianceMatrixCollection & noise);
  CovarianceMatrixCollection getNoise() const;

  /** Accessor to the Cholesky factor */
  TriangularMatrix getCholeskyFactor() const; // lapack
  HMatrix getHMatCholeskyFactor() const; // hmat
  void setCholeskyFactor(const TriangularMatrix & covarianceCholeskyFactor,
                         const HMatrix & covarianceHMatrix);

  /** rho accessor */
  void setStandardizedOutput(const Point & rho);
  Point getStandardizedOutput() const;

  /** Method save() stores the object through the StorageManager */
  void save(Advocate & adv) const override;

  /** Method load() reloads the object from the StorageManager */
  void load(Advocate & adv) override;

private:

  /** Regression matrix (aka F matrix) */
  Matrix regressionMatrix_;

  /** The trend basis */
  Basis basis_;

  /** The trend coefficients */
  Point beta_;

  /** The covariance model */
  CovarianceModel covarianceModel_;

  /** The rho point */
  Point rho_;

  /** optimal log-likelihood value */
  Scalar optimalLogLikelihood_ = 0.0;

  /** Linear algebra method */
  LinearAlgebra linearAlgebraMethod_;

  /** Boolean for Cholesky. */
  Bool hasCholeskyFactor_ = false;

  /** Cholesky factor  */
  TriangularMatrix covarianceCholeskyFactor_;

  /** Cholesky factor when using hmat-oss/hmat */
  HMatrix covarianceHMatrix_;

  /** Noise on the output sample */
  PersistentCollection<CovarianceMatrix> noise_;

}; /* class GaussianProcessFitterResult */


END_NAMESPACE_OPENTURNS

#endif /* OPENTURNS_GAUSSIANPROCESSFITTERRESULT_HXX */

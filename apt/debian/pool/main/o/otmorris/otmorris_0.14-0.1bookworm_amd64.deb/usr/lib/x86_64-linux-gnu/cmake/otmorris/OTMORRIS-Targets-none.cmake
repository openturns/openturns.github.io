#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otmorris" for configuration "None"
set_property(TARGET otmorris APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(otmorris PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotmorris.so.0.0.0"
  IMPORTED_SONAME_NONE "libotmorris.so.0"
  )

list(APPEND _cmake_import_check_targets otmorris )
list(APPEND _cmake_import_check_files_for_otmorris "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotmorris.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

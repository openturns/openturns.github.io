#                                               -*- cmake -*-
#
#  otmeshingConfig.cmake(.in)
#
#  Find otmeshing includes and libraries
#
#  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
#

# Use the following variables to compile and link against otmeshing:
#  OTMESHING_FOUND          - True if otmeshing was found on your system
#  OTMESHING_DEFINITIONS    - Definitions needed to build with otmeshing
#  OTMESHING_INCLUDE_DIRS   - List of directories where otmeshing' header file are
#  OTMESHING_LIBRARY        - Library name
#  OTMESHING_LIBRARIES      - List of libraries to link against
#  OTMESHING_LIBRARY_DIRS   - List of directories containing otmeshing' libraries
#  OTMESHING_ROOT_DIR       - The base directory of otmeshing
#  OTMESHING_VERSION_STRING - A human-readable string containing the version
#  OTMESHING_VERSION_MAJOR  - The major version of otmeshing
#  OTMESHING_VERSION_MINOR  - The minor version of otmeshing
#  OTMESHING_VERSION_PATCH  - The patch version of otmeshing


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was otmeshingConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/x86_64-linux-gnu/cmake/otmeshing" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

####################################################################################

set ( OTMESHING_FOUND 1 )

set ( OTMESHING_DEFINITIONS  "" )
set_and_check (OTMESHING_INCLUDE_DIR  "${PACKAGE_PREFIX_DIR}/include")
set ( OTMESHING_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include;${PACKAGE_PREFIX_DIR}/include" )
set_and_check (OTMESHING_LIBRARY      "otmeshing")
set ( OTMESHING_LIBRARIES    "" )
set ( OTMESHING_LIBRARY_DIRS "${PACKAGE_PREFIX_DIR}/lib/x86_64-linux-gnu;${PACKAGE_PREFIX_DIR}/lib/x86_64-linux-gnu" )
set_and_check (OTMESHING_ROOT_DIR     "${PACKAGE_PREFIX_DIR}")

set ( OTMESHING_VERSION_STRING "0.1" )
set ( OTMESHING_VERSION_MAJOR  "0" )
set ( OTMESHING_VERSION_MINOR  "1" )
set ( OTMESHING_VERSION_PATCH  "" )

set (OTMESHING_SWIG_INCLUDE_DIRS "")
set (OTMESHING_PYTHON_MODULE_PATH "${PACKAGE_PREFIX_DIR}/lib/python3/dist-packages")

# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/otmeshing-Targets.cmake)

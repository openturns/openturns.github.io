#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CoACD::_coacd" for configuration "RelWithDebInfo"
set_property(TARGET CoACD::_coacd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(CoACD::_coacd PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/lib_coacd.so"
  IMPORTED_SONAME_RELWITHDEBINFO "lib_coacd.so"
  )

list(APPEND _cmake_import_check_targets CoACD::_coacd )
list(APPEND _cmake_import_check_files_for_CoACD::_coacd "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/lib_coacd.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

/**
 *
 *   Copyright 2005-2020 Pierre-Henri WUILLEMIN(@LIP6) & Christophe GONZALES(@AMU)
 *   info_at_agrum_dot_org
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */


/**
 * @file
 * @brief Headers of the IMDDI class.
 *
 * @author Jean-Christophe MAGNAN
 */

// =========================================================================
#ifndef GUM_IMDDI_H
#define GUM_IMDDI_H
// =========================================================================
#include <agrum/tools/multidim/implementations/multiDimFunctionGraph.h>
// =========================================================================
#include <agrum/FMDP/learning/datastructure/incrementalGraphLearner.h>
#include <agrum/FMDP/learning/datastructure/leaves/abstractLeaf.h>
#include <agrum/FMDP/learning/datastructure/leaves/concreteLeaf.h>
#include <agrum/FMDP/learning/datastructure/leaves/leafAggregator.h>
#include <agrum/FMDP/learning/datastructure/variableselector.h>
// =========================================================================
#include <agrum/tools/variables/discreteVariable.h>
// =========================================================================

namespace gum {

  /**
   * @class IMDDI
   * @headerfile imddi.h <agrum/FMDP/planning/FunctionGraph/imddi.h>
   * @brief
   * @ingroup fmdp_group
   *
   *
   *
   */

  template < TESTNAME AttributeSelection, bool isScalar = false >
  class IMDDI: public IncrementalGraphLearner< AttributeSelection, isScalar > {
    public:
    // ###################################################################
    /// @name Constructor & destructor.
    // ###################################################################
    /// @{

    // ==========================================================================
    /// Variable Learner constructor
    // ==========================================================================
    IMDDI(MultiDimFunctionGraph< double >* target,
          double                           attributeSelectionThreshold,
          double                           pairSelectionThreshold,
          Set< const DiscreteVariable* >   attributeListe,
          const DiscreteVariable*          learnedValue);

    // ==========================================================================
    /// Reward Learner constructor
    // ==========================================================================
    IMDDI(MultiDimFunctionGraph< double >* target,
          double                           attributeSelectionThreshold,
          double                           pairSelectionThreshold,
          Set< const DiscreteVariable* >   attributeListe);

    // ==========================================================================
    /// Default destructor
    // ==========================================================================
    ~IMDDI();

    /// @}

    // ###################################################################
    /// @name Incrementals methods
    // ###################################################################
    /// @{

    // ==========================================================================
    /// Adds a new observation to the structure
    // ==========================================================================
    void addObservation(const Observation*);

    protected:
    void updateNodeWithObservation_(const Observation* newObs,
                                    NodeId             currentNodeId);

    public:
    // ==========================================================================
    /// Updates the tree after a new observation has been added
    // ==========================================================================
    void updateGraph();

    protected:
    NodeId insertLeafNode_(NodeDatabase< AttributeSelection, isScalar >* nDB,
                           const DiscreteVariable*                       boundVar,
                           Set< const Observation* >*                    sonsMap);

    void chgNodeBoundVar_(NodeId chgedNodeId, const DiscreteVariable* desiredVar);

    void removeNode_(NodeId removedNodeId);

    private:
    void addLeaf__(NodeId);
    void removeLeaf__(NodeId);

    /// @}

    private:
    // ###################################################################
    /// @name Updating private methods
    // ###################################################################
    /// @{

    // ==========================================================================
    /// Computes the score of the given variables for the given node
    // ==========================================================================
    void updateScore__(const DiscreteVariable*, NodeId, VariableSelector& vs);
    void downdateScore__(const DiscreteVariable*, NodeId, VariableSelector& vs);

    // ==========================================================================
    /// For each node in the given set, this methods checks whether or not
    /// we should installed the given variable as a test.
    /// If so, the node is updated
    // ==========================================================================
    void
       updateNodeSet__(Set< NodeId >&, const DiscreteVariable*, VariableSelector&);


    public:
    // ==========================================================================
    ///
    // ==========================================================================
    void updateFunctionGraph();

    private:
    void   rebuildFunctionGraph__();
    NodeId insertLeafInFunctionGraph__(AbstractLeaf*, Int2Type< true >);
    NodeId insertLeafInFunctionGraph__(AbstractLeaf*, Int2Type< false >);

    /// @}
    ///
    public:
    void insertSetOfVars(MultiDimFunctionGraph< double >* ret) const {
      for (SequenceIteratorSafe< const DiscreteVariable* > varIter =
              varOrder__.beginSafe();
           varIter != varOrder__.endSafe();
           ++varIter)
        ret->add(**varIter);
    }

    private:
    Sequence< const DiscreteVariable* > varOrder__;

    LeafAggregator lg__;

    HashTable< NodeId, AbstractLeaf* > leafMap__;

    /// The total number of observation added to this tree
    Idx nbTotalObservation__;

    /// The threshold above which we consider variables to be dependant
    double attributeSelectionThreshold__;

    /// The threshold above which two leaves does not share the same probability
    /// distribution
    // double pairSelectionThreshold__;
  };


} /* namespace gum */

#include <agrum/FMDP/learning/datastructure/imddi_tpl.h>

#endif   // GUM_IMDDI_H

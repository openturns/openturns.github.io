#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otmixmod" for configuration "None"
set_property(TARGET otmixmod APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(otmixmod PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotmixmod.so.0.0.0"
  IMPORTED_SONAME_NONE "libotmixmod.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otmixmod )
list(APPEND _IMPORT_CHECK_FILES_FOR_otmixmod "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotmixmod.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

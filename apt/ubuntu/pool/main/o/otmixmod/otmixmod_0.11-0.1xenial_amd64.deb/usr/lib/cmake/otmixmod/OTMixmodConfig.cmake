#                                               -*- cmake -*-
#
#  otmixmodConfig.cmake(.in)
#
#  Find otmixmod includes and libraries
#
#  (C) Copyright 2008-2013 Phimeca
#

# Use the following variables to compile and link against otmixmod:
#  OTMIXMOD_FOUND          True if otmixmod was found on your system
#  OTMIXMOD_USE_FILE       The file making otmixmod usable
#  OTMIXMOD_DEFINITIONS    Definitions needed to build with otmixmod
#  OTMIXMOD_INCLUDE_DIRS   List of directories where otmixmod' header file are
#  OTMIXMOD_LIBRARIES      List of libraries to link against
#  OTMIXMOD_LIBRARY_DIRS   List of directories containing otmixmod' libraries
#  OTMIXMOD_ROOT_DIR       The base directory of otmixmod
#  OTMIXMOD_VERSION_STRING A human-readable string containing the version
#  OTMIXMOD_VERSION_MAJOR  The major version of otmixmod
#  OTMIXMOD_VERSION_MINOR  The minor version of otmixmod
#  OTMIXMOD_VERSION_PATCH  The patch version of otmixmod

set ( OTMIXMOD_FOUND 1 )
set ( OTMIXMOD_USE_FILE     "/usr/lib/cmake/otmixmod/UseOTMixmod.cmake" )

set ( OTMIXMOD_DEFINITIONS  "-D_LARGEFILE64_SOURCE;-D_LARGEFILE_SOURCE;-D_FORTIFY_SOURCE=2" )
set ( OTMIXMOD_INCLUDE_DIR  "/usr/include" )
set ( OTMIXMOD_INCLUDE_DIRS "/usr/include;/usr/include;/usr/include;/usr/include/libxml2" )
set ( OTMIXMOD_LIBRARIES    "/usr/lib/x86_64-linux-gnu/libtbb.so;/usr/lib/x86_64-linux-gnu/libxml2.so;-lpthread;OT;otmixmod" )
set ( OTMIXMOD_LIBRARY_DIRS "/usr/lib;/usr/lib" )
set ( OTMIXMOD_ROOT_DIR     "/usr" )

set ( OTMIXMOD_VERSION_STRING "0.11" )
set ( OTMIXMOD_VERSION_MAJOR  "0" )
set ( OTMIXMOD_VERSION_MINOR  "11" )
set ( OTMIXMOD_VERSION_PATCH  "" )

set (OTMIXMOD_PYTHON3_MODULE_PATH "lib/python3/dist-packages")

#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otsvm" for configuration "RelWithDebInfo"
set_property(TARGET otsvm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(otsvm PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libotsvm.so.0.0.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libotsvm.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otsvm )
list(APPEND _IMPORT_CHECK_FILES_FOR_otsvm "${_IMPORT_PREFIX}/lib/libotsvm.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

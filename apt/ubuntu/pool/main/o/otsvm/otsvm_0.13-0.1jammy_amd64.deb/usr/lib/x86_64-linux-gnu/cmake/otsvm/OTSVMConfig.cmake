#                                               -*- cmake -*-
#
#  otsvmConfig.cmake(.in)
#
#  Find otsvm includes and libraries
#
#  Copyright 2014-2023 Phimeca
#

# Use the following variables to compile and link against otsvm:
#  OTSVM_FOUND          - True if otsvm was found on your system
#  OTSVM_DEFINITIONS    - Definitions needed to build with otsvm
#  OTSVM_INCLUDE_DIRS   - List of directories where otsvm' header file are
#  OTSVM_LIBRARY        - Library name
#  OTSVM_LIBRARIES      - List of libraries to link against
#  OTSVM_LIBRARY_DIRS   - List of directories containing otsvm' libraries
#  OTSVM_ROOT_DIR       - The base directory of otsvm
#  OTSVM_VERSION_STRING - A human-readable string containing the version
#  OTSVM_VERSION_MAJOR  - The major version of otsvm
#  OTSVM_VERSION_MINOR  - The minor version of otsvm
#  OTSVM_VERSION_PATCH  - The patch version of otsvm

set ( OTSVM_FOUND 1 )

set ( OTSVM_DEFINITIONS  "" )
set ( OTSVM_INCLUDE_DIR  "/usr/include" )
set ( OTSVM_INCLUDE_DIRS "/usr/include;/usr/include" )
set ( OTSVM_LIBRARY      "otsvm" )
set ( OTSVM_LIBRARIES    "OT;otsvm" )
set ( OTSVM_LIBRARY_DIRS "/usr/lib/x86_64-linux-gnu;/usr/lib/x86_64-linux-gnu" )
set ( OTSVM_ROOT_DIR     "/usr" )

set ( OTSVM_VERSION_STRING "0.13" )
set ( OTSVM_VERSION_MAJOR  "0" )
set ( OTSVM_VERSION_MINOR  "13" )
set ( OTSVM_VERSION_PATCH  "" )

set (OTSVM_PYTHON_MODULE_PATH "/usr/lib/x86_64-linux-gnu/python3.10/site-packages")

# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/OTSVM-Targets.cmake)


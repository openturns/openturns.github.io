#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otmeshing" for configuration "None"
set_property(TARGET otmeshing APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(otmeshing PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotmeshing.so.0.0.0"
  IMPORTED_SONAME_NONE "libotmeshing.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otmeshing )
list(APPEND _IMPORT_CHECK_FILES_FOR_otmeshing "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotmeshing.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

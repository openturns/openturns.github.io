//                                               -*- C++ -*-
/**
 *  @brief Class for the Nataf transformationEvaluation evaluation for elliptical
 *
 *  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
#ifndef OPENTURNS_INVERSEROSENBLATTEVALUATION_HXX
#define OPENTURNS_INVERSEROSENBLATTEVALUATION_HXX

#include "openturns/OTprivate.hxx"
#include "openturns/EvaluationImplementation.hxx"
#include "openturns/Matrix.hxx"
#include "openturns/Point.hxx"
#include "openturns/Distribution.hxx"
#include "openturns/StorageManager.hxx"

BEGIN_NAMESPACE_OPENTURNS

/**
 * @class InverseRosenblattEvaluation
 *
 * This class offers an interface for the Nataf function for elliptical distributions
 */
class OT_API InverseRosenblattEvaluation
  : public EvaluationImplementation
{
  CLASSNAME
public:


  /** Default constructor */
  InverseRosenblattEvaluation();

  /** Parameter constructor */
  explicit InverseRosenblattEvaluation(const Distribution & distribution);

  /** Virtual constructor */
  InverseRosenblattEvaluation * clone() const override;

  /** Comparison operator */
  using EvaluationImplementation::operator ==;
  Bool operator ==(const InverseRosenblattEvaluation & other) const;
protected:
  Bool equals(const EvaluationImplementation & other) const override;
public:

  /** Evaluation */
  Point operator () (const Point & inP) const override;

  /** Gradient according to the marginal parameters, computed by central finite differences */
  Matrix parameterGradient(const Point & inP) const override;

  /** Parameters value accessor */
  Point getParameter() const override;
  void setParameter(const Point & parameter) override;
  UnsignedInteger getParameterDimension() const override;

  /** Parameters description accessor */
  Description getParameterDescription() const override;

  /** Accessor for input point dimension */
  UnsignedInteger getInputDimension() const override;

  /** Accessor for output point dimension */
  UnsignedInteger getOutputDimension() const override;

  /** Is it safe to call in parallel? */
  Bool isParallel() const override;

  /** String converter */
  String __repr__() const override;
  String __str__(const String & offset = "") const override;

  /** Method save() stores the object through the StorageManager */
  void save(Advocate & adv) const override;

  /** Method load() reloads the object from the StorageManager */
  void load(Advocate & adv) override;

protected:


private:
  Distribution distribution_;

}; /* InverseRosenblattEvaluation */


END_NAMESPACE_OPENTURNS

#endif /* OPENTURNS_INVERSEROSENBLATTEVALUATION_HXX */

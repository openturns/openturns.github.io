//                                               -*- C++ -*-
/**
 *  @brief The class that implements randomMixtures
 *
 *  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
#ifndef OPENTURNS_LINEARCOMBINATIONDISTRIBUTION_HXX
#define OPENTURNS_LINEARCOMBINATIONDISTRIBUTION_HXX

#include "openturns/Distribution.hxx"
#include "openturns/DistributionFactory.hxx"
#include "openturns/DistributionImplementation.hxx"
#include "openturns/Collection.hxx"
#include "openturns/PersistentCollection.hxx"
#include "openturns/Normal.hxx"
#include "openturns/ResourceMap.hxx"
#include "openturns/SphereUniformNorm.hxx"
#include "openturns/Indices.hxx"
#include "openturns/FFT.hxx"
#include "openturns/GaussKronrod.hxx"

BEGIN_NAMESPACE_OPENTURNS

/**
 * @class LinearCombinationDistribution
 *
 * The class describes the probabilistic concept of LinearCombinationDistribution.
 */
class OT_API LinearCombinationDistribution
  : public DistributionImplementation
{
  CLASSNAME
public:

  typedef Collection<Distribution>               DistributionCollection;
  typedef PersistentCollection<Distribution>     DistributionPersistentCollection;
  typedef PersistentCollection<Complex> ComplexPersistentCollection;
  typedef Collection<DistributionFactory>        DistributionFactoryCollection;

  /** Default constructor */
  LinearCombinationDistribution();

  /** Parameter constructor - 1D */
  explicit LinearCombinationDistribution(const DistributionCollection & coll,
                                         const Scalar constant = 0.0);

  /** Parameter constructor - 1D */
  LinearCombinationDistribution(const DistributionCollection & coll,
                                const Point & weights,
                                const Scalar constant = 0.0);

  /** Parameter constructor - nD */
  LinearCombinationDistribution(const DistributionCollection & coll,
                                const Matrix & weights,
                                const Point & constant);

  /** Parameter constructor - nD */
  LinearCombinationDistribution(const DistributionCollection & coll,
                                const Matrix & weights);

  /** Parameter constructor - nD */
  LinearCombinationDistribution(const DistributionCollection & coll,
                                const Sample & weights,
                                const Point & constant);

  /** Parameter constructor - nD */
  LinearCombinationDistribution(const DistributionCollection & coll,
                                const Sample & weights);

  /** Comparison operator */
  using DistributionImplementation::operator ==;
  Bool operator ==(const LinearCombinationDistribution & other) const;
protected:
  Bool equals(const DistributionImplementation & other) const override;
public:

  /** String converter */
  String __repr__() const override;
  String __str__(const String & offset = "") const override;


  /** Distribution collection accessor */
  DistributionCollection getDistributionCollection() const;

  /** FFT algorithm accessor */
  FFT getFFTAlgorithm() const;
  void setFFTAlgorithm(const FFT & fft);

  /** Constant accessor */
  void setConstant(const Point & constant);
  Point getConstant() const;



  /* Here is the interface that all derived class must implement */

  /** Virtual constructor */
  LinearCombinationDistribution * clone() const override;

  /** Get one realization of the LinearCombinationDistribution */
  Point getRealization() const override;

  /** Get a sample of the LinearCombinationDistribution */
  Sample getSample(const UnsignedInteger size) const override;

  /** Get the DDF of the LinearCombinationDistribution */
  using DistributionImplementation::computeDDF;
  Point computeDDF(const Point & point) const override;

  /** Get the PDF of the LinearCombinationDistribution */
  using DistributionImplementation::computePDF;
  Scalar computePDF(const Point & point) const override;

#ifndef SWIG
  /** Compute the PDF over a regular grid */
  Sample computePDF(const Scalar xMin,
                    const Scalar xMax,
                    const UnsignedInteger pointNumber,
                    Sample & grid) const override;

  /* Compute the PDF of over a regular grid */
  Sample computePDF(const Point & xMin,
                    const Point & xMax,
                    const Indices & pointNumber,
                    Sample & grid) const override;
#endif

  /** Get the i-th marginal distribution */
  Distribution getMarginal(const UnsignedInteger i) const override;

  /** Get the distribution of the marginal distribution corresponding to indices dimensions */
  Distribution getMarginal(const Indices & indices) const override;

protected:

private:

  /** Quantile computation for dimension=1 */
  Scalar computeScalarQuantile(const Scalar prob, const Bool tail = false) const override;

  /** Compute the characteristic function of 1D distributions by difference to a reference Normal distribution with the same mean and the same standard deviation in a regular pattern with cache */
  Complex computeDeltaCharacteristicFunction(const UnsignedInteger index) const;

  /** Compute the characteristic function of nD distributions by difference to a reference Normal distribution with the same mean and the same covariance */
  friend struct AddPDFOn2DGridBody;
  friend struct AddPDFOn3DGridBody;
  Complex computeDeltaCharacteristicFunction(const Point & x) const;

  /** Update cache of the characteristic function */
  void updateCacheDeltaCharacteristicFunction(const Sample & points) const;

  /** Contribution to computePDF on a 1D grid */
  void addPDFOn1DGrid(const Indices & pointNumber, const Point & h, const Point & tau, Sample & result) const;

  /** Contribution to computePDF on a 2D grid */
  void addPDFOn2DGrid(const Indices & pointNumber, const Point & h, const Point & tau, Sample & result) const;

  /** Contribution to computePDF on a 3D grid */
  void addPDFOn3DGrid(const Indices & pointNumber, const Point & h, const Point & tau, Sample & result) const;

public:
  /** Get the CDF of the LinearCombinationDistribution */
  using DistributionImplementation::computeCDF;
  Scalar computeCDF(const Point & point) const override;
  using DistributionImplementation::computeComplementaryCDF;
  Scalar computeComplementaryCDF(const Point & point) const override;

#ifndef SWIG
  /** Compute the CDF over a regular grid */
  Sample computeCDF(const Scalar xMin,
                    const Scalar xMax,
                    const UnsignedInteger pointNumber,
                    Sample & grid) const override;
#endif

  /** Get the probability content of an interval */
  Scalar computeProbability(const Interval & interval) const override;

  /** Compute the quantile over a regular grid */
  using DistributionImplementation::computeQuantile;
  Sample computeQuantile(const Scalar qMin,
                         const Scalar qMax,
                         const UnsignedInteger pointNumber,
                         const Bool tail = false) const override;

  /** Get the minimum volume level set containing a given probability of the distribution */
  LevelSet computeMinimumVolumeLevelSetWithThreshold(const Scalar prob, Scalar & thresholdOut) const override;

  /** Get the characteristic function of the distribution, i.e. phi(u) = E(exp(I*u*X)) */
  using DistributionImplementation::computeCharacteristicFunction;
  Complex computeCharacteristicFunction(const Scalar x) const override;
  Complex computeCharacteristicFunction(const Point & x) const override;
  using DistributionImplementation::computeLogCharacteristicFunction;
  Complex computeLogCharacteristicFunction(const Scalar x) const override;
  Complex computeLogCharacteristicFunction(const Point & x) const override;

  /** Get the PDF gradient of the distribution */
  using DistributionImplementation::computePDFGradient;
  Point computePDFGradient(const Point & point) const override;

  /** Get the CDF gradient of the distribution */
  using DistributionImplementation::computeCDFGradient;
  Point computeCDFGradient(const Point & point) const override;

  /** Parameters value and description accessor */
  PointWithDescriptionCollection getParametersCollection() const override;

  /** Parameters value accessors */
  void setParameter(const Point & parameter) override;
  Point getParameter() const override;

  /** Parameters description accessor */
  Description getParameterDescription() const override;

protected:
  void setDistributionCollectionAndWeights(const DistributionCollection & coll,
      const Matrix & weights,
      const Bool simplifyAtoms);

public:
  /** Weights distribution accessor */
  Matrix getWeights() const;

  /** Get a position indicator for a 1D distribution */
  Scalar getPositionIndicator() const override;

  /** Get a dispersion indicator for a 1D distribution */
  Scalar getDispersionIndicator() const override;

  /** BlockMin accessor */
  void setBlockMin(const UnsignedInteger blockMin);
  UnsignedInteger getBlockMin() const;

  /** BlockMax accessor */
  void setBlockMax(const UnsignedInteger blockMax);
  UnsignedInteger getBlockMax() const;

  /** MaxSize accessor */
  void setMaxSize(const UnsignedInteger maxSize);
  UnsignedInteger getMaxSize() const;

  /** Alpha accessor */
  void setAlpha(const Scalar alpha);
  Scalar getAlpha() const;

  /** Beta accessor */
  void setBeta(const Scalar beta);
  Scalar getBeta() const;

  /** Reference bandwidth accessor */
  void setReferenceBandwidth(const Point & bandwidth);
  Point getReferenceBandwidth() const;

  /** PDF epsilon accessor. For other distributions, it is a read-only attribute. */
  void setPDFPrecision(const Scalar pdfPrecision);

  /** CDF epsilon accessor. For other distributions, it is a read-only attribute. */
  void setCDFPrecision(const Scalar cdfPrecision);

  /** Project a LinearCombinationDistribution distribution over a collection of DistributionFactory by using sampling and Kolmogorov distance. */
  DistributionCollection project(const DistributionFactoryCollection & factoryCollection,
                                 Point & kolmogorovNormOut,
                                 const UnsignedInteger size = ResourceMap::GetAsUnsignedInteger( "LinearCombinationDistribution-ProjectionDefaultSize" )) const;

  /** Tell if the distribution has independent copula */
  Bool hasIndependentCopula() const override;

  /** Tell if the distribution has elliptical copula */
  Bool hasEllipticalCopula() const override;

  /** Check if the distribution is elliptical */
  Bool isElliptical() const override;

  /** Check if the distribution is continuous */
  Bool isContinuous() const override;

  /** Check if the distribution is discrete */
  Bool isDiscrete() const override;

  /** Tell if the distribution is integer valued */
  Bool isIntegral() const override;

  /** Get the support of a discrete distribution that intersect a given interval */
  using DistributionImplementation::getSupport;
  Sample getSupport(const Interval & interval) const override;

  /** Method save() stores the object through the StorageManager */
  void save(Advocate & adv) const override;

  /** Method load() reloads the object from the StorageManager */
  void load(Advocate & adv) override;

protected:
  /** Compute the numerical range of the distribution given the parameters values */
  void computeRange() override;

  /** Get the mean of a randomMixture */
  void computeMean() const override;

  /** Get the covariance of a randomMixture */
  void computeCovariance() const override;

private:
  /** Compute the left-hand sum in Poisson's summation formula for the equivalent normal */
  Scalar computeEquivalentNormalPDFSum(const Scalar x) const;
  Scalar computeEquivalentNormalCDFSum(const Scalar s, const Scalar t) const;

  friend struct DeltaContributionAccumulator;
  Scalar computeEquivalentNormalPDFSum(const Point & y, const Point & gridStep,
                                       UnsignedInteger imax, UnsignedInteger & levelMax) const;
public:
  /** Get the standard deviation of the distribution */
  Point getStandardDeviation() const override;

  /** Get the skewness of the distribution */
  Point getSkewness() const override;

  /** Get the kurtosis of the distribution */
  Point getKurtosis() const override;

private:
  /** Compute the position indicator */
  void computePositionIndicator() const;

  /** Compute the dispersion indicator */
  void computeDispersionIndicator() const;

  /** Compute the reference bandwidth. It is defined as the maximum bandwidth
      that allow a precise computation of the PDF over the range
      [positionIndicator_ +/- bandBeta * dispersionIndicator_] */
  void computeReferenceBandwidth(const Bool recycleCache = false);

  /** Number of blocks allowed at the current adaptation stage */
  UnsignedInteger effectiveKmax(const UnsignedInteger kmax) const;

  /** Adapt the confidence band by doubling beta until the mass outside the
      band [positionIndicator_ +/- beta * dispersionIndicator_] is negligible */
  void adaptBand();

  /** Carry over the characteristic function values of the previous lattice
      into the current one when the previous lattice is included in the
      current one */
  void recycleCharacteristicValues(const SphereUniformNorm & oldMesher,
                                   const Point & oldBandwidth,
                                   const UnsignedInteger oldStoredSize);

  /** Compute the equivalent normal distribution, i.e. with the same mean and
      the same standard deviation */
  void computeEquivalentNormal();

  /** The collection of distribution of the randomMixture */
  DistributionPersistentCollection distributionCollection_;

  /** The constant term of the mixture */
  Point constant_;

  /** The Weight matrix */
  Matrix weights_;

  /** inverse weight matrix if defined */
  Matrix inverseWeights_;

  /** Determinant of inverse weights */
  Scalar detWeightsInverse_;

  /** FFT algorithm */
  FFT fftAlgorithm_;

  /** The LinearCombinationDistribution is analytic if size of collection = dimension */
  Bool isAnalytical_;

  /** Position indicator */
  mutable Scalar positionIndicator_;
  mutable Bool isAlreadyComputedPositionIndicator_;

  /** Dispersion indicator */
  mutable Scalar dispersionIndicator_;
  mutable Bool isAlreadyComputedDispersionIndicator_;

  /** Minimum number of blocks to consider for PDF and CDF computation */
  UnsignedInteger blockMin_;

  /** Maximum number of blocks to consider for PDF and CDF computation */
  UnsignedInteger blockMax_;

  /** Reference bandwidth */
  Point referenceBandwidth_;

  /** Reference bandwidth factor */
  Scalar referenceBandwidthFactor_;

  /** Maximum size of the cache for the CharacteristicFunction values */
  UnsignedInteger maxSize_;

  /** Index of the top of the cache */
  mutable UnsignedInteger storedSize_;

  /** Cache for the characteristic function values */
  mutable ComplexPersistentCollection characteristicValuesCache_;

  /** A priori range of PDF and CDF argument expressed in dispersionIndicator units */
  Scalar alpha_;

  /** Distance from the boundary of the a priori range at which the PDF is negligible */
  Scalar beta_;

  /** Effective distance from the position indicator at which the PDF is
      negligible, after the adaptation of the confidence band */
  Scalar bandBeta_;

  /** Center of the confidence band, per axis */
  Point bandCenter_;

  /** Scale of the confidence band, per axis */
  Point bandScale_;

  /** Requested precision for PDF computation */
  mutable Scalar pdfPrecision_;

  /** Requested precision for CDF computation */
  Scalar cdfPrecision_;

  /** Normal distribution with the same mean and standard deviation than the LinearCombinationDistribution */
  Normal equivalentNormal_;

  /** Helper object to retrieve points on a regular grid */
  SphereUniformNorm gridMesher_;

  /** Integration algorithm */
  GaussKronrod algo_;

}; /* class LinearCombinationDistribution */


END_NAMESPACE_OPENTURNS

#endif /* OPENTURNS_LINEARCOMBINATIONDISTRIBUTION_HXX */

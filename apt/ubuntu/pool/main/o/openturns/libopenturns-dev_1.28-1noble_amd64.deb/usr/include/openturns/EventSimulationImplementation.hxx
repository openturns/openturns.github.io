//                                               -*- C++ -*-
/**
 *  @brief EventSimulationImplementation is a generic view of simulation methods for computing
 * probabilities and related quantities by sampling and estimation
 *
 *  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
#ifndef OPENTURNS_EVENTSIMULATIONIMPLEMENTATION_HXX
#define OPENTURNS_EVENTSIMULATIONIMPLEMENTATION_HXX

#include "openturns/SimulationAlgorithm.hxx"
#include "openturns/HistoryStrategy.hxx"
#include "openturns/Compact.hxx"
#include "openturns/Last.hxx"
#include "openturns/Graph.hxx"
#include "openturns/ProbabilitySimulationResultImplementation.hxx"
#include "openturns/ProbabilitySimulationResult.hxx"
#include "openturns/RandomVector.hxx"

BEGIN_NAMESPACE_OPENTURNS

// Forward declaration for restricted access to the history bridge
class ActiveLearningReliabilityAlgorithm;

/**
 * @class EventSimulationImplementation
 */

class OT_API EventSimulationImplementation
  : public SimulationAlgorithm
{

  CLASSNAME
public:

  /** Constructor with parameters */
  explicit EventSimulationImplementation(const RandomVector & event,
                                         const HistoryStrategy & convergenceStrategy = Compact());

  /** Virtual constructor */
  EventSimulationImplementation * clone() const override;

  /** Event accessor */
  RandomVector getEvent() const;

  /** Event accessor */
  virtual void setEvent(const RandomVector & event);

  /** Result accessor */
  ProbabilitySimulationResult getResult() const;

  /** String converter */
  String __repr__() const override;

  /** Performs the actual computation. */
  void run() override;

  /** Draw the probability convergence at the given level */
  Graph drawProbabilityConvergence(const Scalar level = ProbabilitySimulationResultImplementation::GetDefaultConfidenceLevel()) const;

  /** Method save() stores the object through the StorageManager */
  void save(Advocate & adv) const override;

  /** Method load() reloads the object from the StorageManager */
  void load(Advocate & adv) override;

  /** Input accessor */
  virtual Sample getInputSample() const;

  /** Setter keep sample */
  virtual void setKeepSample(const Bool);

  /** For save/load mechanism*/
  EventSimulationImplementation(const HistoryStrategy & convergenceStrategy = Compact());

protected:

  /** Result accessor */
  void setResult(const ProbabilitySimulationResultImplementation & result);

  /** Current result with full dynamic type, for per-iteration histories.
      Restricted to ActiveLearningReliabilityAlgorithm (friend): it has no
      meaning as standalone public API. The default implementation wraps
      the base result; simulators with an extended result type override it. */
  virtual ProbabilitySimulationResult getHistoryResult() const;

  /** Compute the block sample and the points that realized the event */
  virtual Sample computeBlockSample();

  friend class Factory<EventSimulationImplementation>;
  friend class ActiveLearningReliabilityAlgorithm;

  // The event we are computing the probability of
  RandomVector event_;

  // Result of the simulation
  ProbabilitySimulationResultImplementation result_;

} ; /* class EventSimulationImplementation */


END_NAMESPACE_OPENTURNS

#endif /* OPENTURNS_EVENTSIMULATIONIMPLEMENTATION_HXX */

//                                               -*- C++ -*-
/**
 *  @brief Class for the InverseNataf transformation evaluation for elliptical
 *
 *  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
#ifndef OPENTURNS_INVERSENATAFELLIPTICALDISTRIBUTIONEVALUATION_HXX
#define OPENTURNS_INVERSENATAFELLIPTICALDISTRIBUTIONEVALUATION_HXX

#include "openturns/OTprivate.hxx"
#include "openturns/LinearEvaluation.hxx"
#include "openturns/TriangularMatrix.hxx"
#include "openturns/Point.hxx"
#include "openturns/StorageManager.hxx"

BEGIN_NAMESPACE_OPENTURNS

/**
 * @class InverseNatafEllipticalDistributionEvaluation
 *
 * This class offers an interface for the InverseNataf function for elliptical distributions
 */
class OT_API InverseNatafEllipticalDistributionEvaluation
  : public LinearEvaluation
{
  CLASSNAME
public:


  /** Default constructor */
  InverseNatafEllipticalDistributionEvaluation();

  /** Parameter constructor */
  InverseNatafEllipticalDistributionEvaluation(const Point & mean,
      const TriangularMatrix & cholesky);

  /** Parameter constructor with recorded (mu, sigma) scales */
  InverseNatafEllipticalDistributionEvaluation(const Point & mean,
      const TriangularMatrix & cholesky,
      const Point & parameters);

  /** Virtual constructor */
  InverseNatafEllipticalDistributionEvaluation * clone() const override;

  /** Comparison operator */
  using EvaluationImplementation::operator ==;
  Bool operator ==(const InverseNatafEllipticalDistributionEvaluation &) const;
protected:
  Bool equals(const EvaluationImplementation & other) const override;
public:

  /** Gradient according to the marginal parameters */
  Matrix parameterGradient(const Point & inP) const override;

  /** Parameters value accessor, as (mu, sigma) */
  Point getParameter() const override;
  void setParameter(const Point & parameter) override;

  /** Parameters description accessor */
  Description getParameterDescription() const override;

  /** Accessor for parameters dimension */
  UnsignedInteger getParameterDimension() const override;

  /** String converter */
  String __repr__() const override;

  /** Method save() stores the object through the StorageManager */
  void save(Advocate & adv) const override;

  /** Method load() reloads the object from the StorageManager */
  void load(Advocate & adv) override;

protected:


private:

}; /* InverseNatafEllipticalDistributionEvaluation */


END_NAMESPACE_OPENTURNS

#endif /* OPENTURNS_INVERSENATAFELLIPTICALDISTRIBUTIONEVALUATION_HXX */

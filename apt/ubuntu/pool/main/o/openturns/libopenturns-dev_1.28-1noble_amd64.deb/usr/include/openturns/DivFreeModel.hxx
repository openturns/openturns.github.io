//                                               -*- C++ -*-
/**
 *
 *  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
#ifndef OPENTURNS_DIVFREEMODEL_HXX
#define OPENTURNS_DIVFREEMODEL_HXX

#include "openturns/CovarianceModelImplementation.hxx"
#include "openturns/CovarianceModel.hxx"

BEGIN_NAMESPACE_OPENTURNS

class OT_API DivFreeModel
  : public CovarianceModelImplementation
{

  CLASSNAME

public:

  /** Default constructor */
  explicit DivFreeModel(const UnsignedInteger inputDimension = 2);

#ifdef SWIG
  /** Dummy copy ctor to fix overload precedence */
  DivFreeModel(const DivFreeModel & other);
#endif

  /** Parameters constructor */
  explicit DivFreeModel(const CovarianceModel & model);

  /** Virtual copy constructor */
  DivFreeModel * clone() const override;

  /** Computation of the covariance function */
  using CovarianceModelImplementation::operator();
  SquareMatrix operator()(const Point & s, const Point & t) const override;
  SquareMatrix operator()(const Point & tau) const override;

  /** Gradient */
  Matrix partialGradient(const Point & s,
                         const Point & t) const override;

  /** Hessian of the (0, 0) output component, semi-analytic via H stencil */
  SymmetricMatrix partialHessian(const Point & s,
                                 const Point & t) const override;

  /** Parameter gradient, semi-analytic via base parameterHessian */
  Matrix parameterGradient(const Point & s,
                           const Point & t) const override;

  /** Scalar interface (for 1D case) */
  Scalar computeAsScalar(const Point & s, const Point & t) const override;
  Scalar computeAsScalar(const Point & tau) const override;
  Scalar computeAsScalar(const Scalar s, const Scalar t) const override;
  Scalar computeAsScalar(const Scalar tau) const override;
  Scalar computeAsScalar(const Collection<Scalar>::const_iterator & s_begin,
                         const Collection<Scalar>::const_iterator & t_begin) const override;

  /** Is it a stationary covariance model ? */
  Bool isStationary() const override;

  /** Is it a diagonal covariance model ? Always false: the divergence couples
      the output components, so the output blocks are full. The base flag is
      left untouched on purpose (outputCorrelation framework owned by upstream). */
  Bool isDiagonal() const override;

  /** Scale accessor */
  void setScale(const Point & scale) override;

  /** Parameter accessor, forwarded to the underlying model */
  Point getParameter() const override;
  void setParameter(const Point & parameter) override;
  Description getParameterDescription() const override;
  Point getFullParameter() const override;
  void setFullParameter(const Point & parameter) override;
  Description getFullParameterDescription() const override;
  Indices getActiveParameter() const override;
  void setActiveParameter(const Indices & active) override;

  /** Comparison operator */
  using CovarianceModelImplementation::operator ==;
  Bool operator ==(const DivFreeModel & other) const;

  /** String converter */
  String __repr__() const override;

  /** String converter */
  String __str__(const String & offset = "") const override;

  /** Underlying model accessor */
  CovarianceModel getCovarianceModel() const;

  /** Method save() stores the object through the StorageManager */
  void save(Advocate & adv) const override;

  /** Method load() reloads the object from the StorageManager */
  void load(Advocate & adv) override;

private:

  Bool equals(const CovarianceModelImplementation & other) const override;

  /** The underlying scalar covariance model */
  CovarianceModel model_;

} ; /* class DivFreeModel */

END_NAMESPACE_OPENTURNS

#endif

#                                               -*- cmake -*-
#
#  OTSubsetInverseConfig.cmake(.in)
#
#  Find OTSubsetInverse includes and libraries
#
#  Copyright (C) 2005-2014 Phimeca
#

# Use the following variables to compile and link against OTSubsetInverse:
#  OTSUBSETINVERSE_FOUND          - True if OTSubsetInverse was found on your system
#  OTSUBSETINVERSE_USE_FILE       - The file making OTSubsetInverse usable
#  OTSUBSETINVERSE_DEFINITIONS    - Definitions needed to build with OTSubsetInverse
#  OTSUBSETINVERSE_INCLUDE_DIRS   - List of directories where OTSubsetInverse' header file are
#  OTSUBSETINVERSE_LIBRARY        - Library name
#  OTSUBSETINVERSE_LIBRARIES      - List of libraries to link against
#  OTSUBSETINVERSE_LIBRARY_DIRS   - List of directories containing OTSubsetInverse' libraries
#  OTSUBSETINVERSE_ROOT_DIR       - The base directory of OTSubsetInverse
#  OTSUBSETINVERSE_VERSION_STRING - A human-readable string containing the version
#  OTSUBSETINVERSE_VERSION_MAJOR  - The major version of OTSubsetInverse
#  OTSUBSETINVERSE_VERSION_MINOR  - The minor version of OTSubsetInverse
#  OTSUBSETINVERSE_VERSION_PATCH  - The patch version of OTSubsetInverse

set ( OTSUBSETINVERSE_FOUND 1 )
set ( OTSUBSETINVERSE_USE_FILE     "/usr/lib/cmake/ottemplate/UseOTSubsetInverse.cmake" )

set ( OTSUBSETINVERSE_DEFINITIONS  "-D_LARGEFILE64_SOURCE;-D_LARGEFILE_SOURCE;-D_FORTIFY_SOURCE=2" )
set ( OTSUBSETINVERSE_INCLUDE_DIR  "/usr/include" )
set ( OTSUBSETINVERSE_INCLUDE_DIRS "/usr/include;/usr/include;/usr/include;/usr/include/libxml2" )
set ( OTSUBSETINVERSE_LIBRARY      "ottemplate" )
set ( OTSUBSETINVERSE_LIBRARIES    "/usr/lib/x86_64-linux-gnu/libtbb.so;/usr/lib/x86_64-linux-gnu/libxml2.so;-lpthread;OT;ottemplate" )
set ( OTSUBSETINVERSE_LIBRARY_DIRS "/usr/lib;/usr/lib" )
set ( OTSUBSETINVERSE_ROOT_DIR     "/usr" )

set ( OTSUBSETINVERSE_VERSION_STRING "1.7" )
set ( OTSUBSETINVERSE_VERSION_MAJOR  "1" )
set ( OTSUBSETINVERSE_VERSION_MINOR  "7" )
set ( OTSUBSETINVERSE_VERSION_PATCH  "" )

set (OTSUBSETINVERSE_PYTHON3_MODULE_PATH "/usr/lib/python3/dist-packages")

# CMAKE_CURRENT_LIST_DIR defined since 2.8.3
if (CMAKE_VERSION VERSION_LESS 2.8.3)
  get_filename_component (CMAKE_CURRENT_LIST_DIR ${CMAKE_CURRENT_LIST_FILE} PATH)
endif ()
# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/OTSubsetInverse-Targets.cmake)

#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otpmml" for configuration "RelWithDebInfo"
set_property(TARGET otpmml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(otpmml PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "/usr/lib/libotpmml.so.0.0.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libotpmml.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otpmml )
list(APPEND _IMPORT_CHECK_FILES_FOR_otpmml "/usr/lib/libotpmml.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

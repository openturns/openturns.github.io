#                                               -*- cmake -*-
#
#  otfftwConfig.cmake(.in)
#
#  Find otfftw includes and libraries
#
#  (C) Copyright 2008-2013 Phimeca
#

# Use the following variables to compile and link against otfftw:
#  OTFFTW_FOUND          - True if otfftw was found on your system
#  OTFFTW_USE_FILE       - The file making otfftw usable
#  OTFFTW_DEFINITIONS    - Definitions needed to build with otfftw
#  OTFFTW_INCLUDE_DIRS   - List of directories where otfftw' header file are
#  OTFFTW_LIBRARY        - Library name
#  OTFFTW_LIBRARIES      - List of libraries to link against
#  OTFFTW_LIBRARY_DIRS   - List of directories containing otfftw' libraries
#  OTFFTW_ROOT_DIR       - The base directory of otfftw
#  OTFFTW_VERSION_STRING - A human-readable string containing the version
#  OTFFTW_VERSION_MAJOR  - The major version of otfftw
#  OTFFTW_VERSION_MINOR  - The minor version of otfftw
#  OTFFTW_VERSION_PATCH  - The patch version of otfftw

set ( OTFFTW_FOUND 1 )
set ( OTFFTW_USE_FILE     "/usr/lib/cmake/otfftw/Useotfftw.cmake" )

set ( OTFFTW_DEFINITIONS  "-D_FORTIFY_SOURCE=2" )
set ( OTFFTW_INCLUDE_DIR  "/usr/include" )
set ( OTFFTW_INCLUDE_DIRS "/usr/include;/usr/include;/usr/include;/usr/include/libxml2" )
set ( OTFFTW_LIBRARY      "otfftw" )
set ( OTFFTW_LIBRARIES    "/usr/lib/x86_64-linux-gnu/libtbb.so;/usr/lib/x86_64-linux-gnu/libxml2.so;-lpthread;OT;otfftw" )
set ( OTFFTW_LIBRARY_DIRS "/usr/lib;/usr/lib" )
set ( OTFFTW_ROOT_DIR     "/usr" )

set ( OTFFTW_VERSION_STRING "0.10" )
set ( OTFFTW_VERSION_MAJOR  "0" )
set ( OTFFTW_VERSION_MINOR  "10" )
set ( OTFFTW_VERSION_PATCH  "" )

set (OTFFTW_PYTHON3_MODULE_PATH "lib/python3/dist-packages")

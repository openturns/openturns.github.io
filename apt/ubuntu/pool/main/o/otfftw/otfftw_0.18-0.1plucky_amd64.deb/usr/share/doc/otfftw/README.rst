.. image:: https://github.com/openturns/otfftw/actions/workflows/build.yml/badge.svg?branch=master
    :target: https://github.com/openturns/otfftw/actions/workflows/build.yml

OTFFTW Module
=============

FFT module for OpenTURNS

More information can found at http://www.openturns.org


Installation
============
Please see the http://trac.openturns.org/wiki/Modules
for instructions on installing OpenTURNS modules on various platforms from binaries or sources.

-- The OpenTURNS team

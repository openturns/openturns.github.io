#                                               -*- cmake -*-
#
#  otagrConfig.cmake(.in)
#
#  Find otagr includes and libraries
#
#  Copyright 2005-2024 Airbus-LIP6-Phimeca
#

# Use the following variables to compile and link against otagr:
#  OTAGRUM_FOUND          - True if otagr was found on your system
#  OTAGRUM_DEFINITIONS    - Definitions needed to build with otagr
#  OTAGRUM_INCLUDE_DIRS   - List of directories where otagr' header file are
#  OTAGRUM_LIBRARY        - Library name
#  OTAGRUM_LIBRARIES      - List of libraries to link against
#  OTAGRUM_LIBRARY_DIRS   - List of directories containing otagr' libraries
#  OTAGRUM_ROOT_DIR       - The base directory of otagr
#  OTAGRUM_VERSION_STRING - A human-readable string containing the version
#  OTAGRUM_VERSION_MAJOR  - The major version of otagr
#  OTAGRUM_VERSION_MINOR  - The minor version of otagr
#  OTAGRUM_VERSION_PATCH  - The patch version of otagr

set ( OTAGRUM_FOUND 1 )

set ( OTAGRUM_DEFINITIONS  "-DOLD_HEADER_FILENAME;-DHDF_NO_NAMESPACE;-DNO_STATIC_CAST" )
set ( OTAGRUM_INCLUDE_DIR  "/usr/include" )
set ( OTAGRUM_INCLUDE_DIRS "/usr/include;/usr/include" )
set ( OTAGRUM_LIBRARY      "otagrum" )
set ( OTAGRUM_LIBRARIES    "OT;otagrum" )
set ( OTAGRUM_LIBRARY_DIRS "/usr/lib/x86_64-linux-gnu;/usr/lib/x86_64-linux-gnu" )
set ( OTAGRUM_ROOT_DIR     "/usr" )

set ( OTAGRUM_VERSION_STRING "0.10" )
set ( OTAGRUM_VERSION_MAJOR  "0" )
set ( OTAGRUM_VERSION_MINOR  "10" )
set ( OTAGRUM_VERSION_PATCH  "" )

set (OTAGRUM_PYTHON_MODULE_PATH "/usr/lib/python3.12/site-packages")

# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/otagrum-Targets.cmake)

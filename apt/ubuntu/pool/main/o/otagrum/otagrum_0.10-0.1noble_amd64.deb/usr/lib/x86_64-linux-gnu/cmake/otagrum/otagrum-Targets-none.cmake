#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otagrum" for configuration "None"
set_property(TARGET otagrum APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(otagrum PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotagrum.so.0.0.0"
  IMPORTED_SONAME_NONE "libotagrum.so.0"
  )

list(APPEND _cmake_import_check_targets otagrum )
list(APPEND _cmake_import_check_files_for_otagrum "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotagrum.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

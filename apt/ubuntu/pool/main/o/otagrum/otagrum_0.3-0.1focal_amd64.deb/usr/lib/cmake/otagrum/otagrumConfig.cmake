#                                               -*- cmake -*-
#
#  otagrConfig.cmake(.in)
#
#  Find otagr includes and libraries
#
#  Copyright (C) 2005-2014 Phimeca
#

# Use the following variables to compile and link against otagr:
#  OTAGRUM_FOUND          - True if otagr was found on your system
#  OTAGRUM_USE_FILE       - The file making otagr usable
#  OTAGRUM_DEFINITIONS    - Definitions needed to build with otagr
#  OTAGRUM_INCLUDE_DIRS   - List of directories where otagr' header file are
#  OTAGRUM_LIBRARY        - Library name
#  OTAGRUM_LIBRARIES      - List of libraries to link against
#  OTAGRUM_LIBRARY_DIRS   - List of directories containing otagr' libraries
#  OTAGRUM_ROOT_DIR       - The base directory of otagr
#  OTAGRUM_VERSION_STRING - A human-readable string containing the version
#  OTAGRUM_VERSION_MAJOR  - The major version of otagr
#  OTAGRUM_VERSION_MINOR  - The minor version of otagr
#  OTAGRUM_VERSION_PATCH  - The patch version of otagr

set ( OTAGRUM_FOUND 1 )
set ( OTAGRUM_USE_FILE     "/usr/lib/cmake/otagrum/Useotagrum.cmake" )

set ( OTAGRUM_DEFINITIONS  "" )
set ( OTAGRUM_INCLUDE_DIR  "/usr/include" )
set ( OTAGRUM_INCLUDE_DIRS "/usr/include;/usr/include;/usr/include;/usr/include/libxml2" )
set ( OTAGRUM_LIBRARY      "otagrum" )
set ( OTAGRUM_LIBRARIES    "/usr/lib/x86_64-linux-gnu/libtbb.so;/usr/lib/x86_64-linux-gnu/libxml2.so;-lpthread;OT;otagrum" )
set ( OTAGRUM_LIBRARY_DIRS "/usr/lib;/usr/lib" )
set ( OTAGRUM_ROOT_DIR     "/usr" )

set ( OTAGRUM_VERSION_STRING "0.3" )
set ( OTAGRUM_VERSION_MAJOR  "0" )
set ( OTAGRUM_VERSION_MINOR  "3" )
set ( OTAGRUM_VERSION_PATCH  "" )

set (OTAGRUM_PYTHON3_MODULE_PATH "/usr/lib/python3/dist-packages")

# CMAKE_CURRENT_LIST_DIR defined since 2.8.3
if (CMAKE_VERSION VERSION_LESS 2.8.3)
  get_filename_component (CMAKE_CURRENT_LIST_DIR ${CMAKE_CURRENT_LIST_FILE} PATH)
endif ()
# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/otagr-Targets.cmake)

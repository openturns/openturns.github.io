#                                               -*- cmake -*-
#
#  OTMORRISConfig.cmake(.in)
#
#  Find OTMORRIS includes and libraries
#
#  Copyright 2005-2018 Phimeca
#

# Use the following variables to compile and link against OTMORRIS:
#  OTMORRIS_FOUND          - True if OTMORRIS was found on your system
#  OTMORRIS_USE_FILE       - The file making OTMORRIS usable
#  OTMORRIS_DEFINITIONS    - Definitions needed to build with OTMORRIS
#  OTMORRIS_INCLUDE_DIRS   - List of directories where OTMORRIS' header file are
#  OTMORRIS_LIBRARY        - Library name
#  OTMORRIS_LIBRARIES      - List of libraries to link against
#  OTMORRIS_LIBRARY_DIRS   - List of directories containing OTMORRIS' libraries
#  OTMORRIS_ROOT_DIR       - The base directory of OTMORRIS
#  OTMORRIS_VERSION_STRING - A human-readable string containing the version
#  OTMORRIS_VERSION_MAJOR  - The major version of OTMORRIS
#  OTMORRIS_VERSION_MINOR  - The minor version of OTMORRIS
#  OTMORRIS_VERSION_PATCH  - The patch version of OTMORRIS

set ( OTMORRIS_FOUND 1 )
set ( OTMORRIS_USE_FILE     "/usr/lib/cmake/otmorris/UseOTMORRIS.cmake" )

set ( OTMORRIS_DEFINITIONS  "" )
set ( OTMORRIS_INCLUDE_DIR  "/usr/include" )
set ( OTMORRIS_INCLUDE_DIRS "/usr/include;/usr/include" )
set ( OTMORRIS_LIBRARY      "otmorris" )
set ( OTMORRIS_LIBRARIES    "OT;otmorris" )
set ( OTMORRIS_LIBRARY_DIRS "/usr/lib/x86_64-linux-gnu;/usr/lib" )
set ( OTMORRIS_ROOT_DIR     "/usr" )

set ( OTMORRIS_VERSION_STRING "0.13" )
set ( OTMORRIS_VERSION_MAJOR  "0" )
set ( OTMORRIS_VERSION_MINOR  "13" )
set ( OTMORRIS_VERSION_PATCH  "" )

set (OTMORRIS_PYTHON3_MODULE_PATH "/usr/lib/python3.9/site-packages")

# CMAKE_CURRENT_LIST_DIR defined since 2.8.3
if (CMAKE_VERSION VERSION_LESS 2.8.3)
  get_filename_component (CMAKE_CURRENT_LIST_DIR ${CMAKE_CURRENT_LIST_FILE} PATH)
endif ()
# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/OTMORRIS-Targets.cmake)

#                                               -*- cmake -*-
#
#  OTMORRISConfig.cmake(.in)
#
#  Find OTMORRIS includes and libraries
#
#  Copyright 2005-2024 Airbus-EDF-IMACS-ONERA-Phimeca
#

# Use the following variables to compile and link against OTMORRIS:
#  OTMORRIS_FOUND          - True if OTMORRIS was found on your system
#  OTMORRIS_DEFINITIONS    - Definitions needed to build with OTMORRIS
#  OTMORRIS_INCLUDE_DIRS   - List of directories where OTMORRIS' header file are
#  OTMORRIS_LIBRARY        - Library name
#  OTMORRIS_LIBRARIES      - List of libraries to link against
#  OTMORRIS_LIBRARY_DIRS   - List of directories containing OTMORRIS' libraries
#  OTMORRIS_ROOT_DIR       - The base directory of OTMORRIS
#  OTMORRIS_VERSION_STRING - A human-readable string containing the version
#  OTMORRIS_VERSION_MAJOR  - The major version of OTMORRIS
#  OTMORRIS_VERSION_MINOR  - The minor version of OTMORRIS
#  OTMORRIS_VERSION_PATCH  - The patch version of OTMORRIS

set ( OTMORRIS_FOUND 1 )

set ( OTMORRIS_DEFINITIONS  "" )
set ( OTMORRIS_INCLUDE_DIR  "/usr/include" )
set ( OTMORRIS_INCLUDE_DIRS "/usr/include;/usr/include" )
set ( OTMORRIS_LIBRARY      "otmorris" )
set ( OTMORRIS_LIBRARIES    "OT;otmorris" )
set ( OTMORRIS_LIBRARY_DIRS "/usr/lib/x86_64-linux-gnu;/usr/lib/x86_64-linux-gnu" )
set ( OTMORRIS_ROOT_DIR     "/usr" )

set ( OTMORRIS_VERSION_STRING "0.16" )
set ( OTMORRIS_VERSION_MAJOR  "0" )
set ( OTMORRIS_VERSION_MINOR  "16" )
set ( OTMORRIS_VERSION_PATCH  "" )

set (OTMORRIS_PYTHON_MODULE_PATH "/usr/lib/x86_64-linux-gnu/python3.12/site-packages")

# Our library dependencies (contains definitions for IMPORTED targets)
include (${CMAKE_CURRENT_LIST_DIR}/OTMORRIS-Targets.cmake)

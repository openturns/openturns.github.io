#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otmorris" for configuration "RelWithDebInfo"
set_property(TARGET otmorris APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(otmorris PROPERTIES
  IMPORTED_LINK_INTERFACE_LIBRARIES_RELWITHDEBINFO "OT"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libotmorris.so.0.0.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libotmorris.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otmorris )
list(APPEND _IMPORT_CHECK_FILES_FOR_otmorris "${_IMPORT_PREFIX}/lib/libotmorris.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

// MeasureEvaluation docstrings are defined in MeasureEvaluationImplementation_doc.i.in

%feature("docstring") OTROBOPT::MeasureEvaluation
OTROBOPT_MeasureEvaluation_doc
%feature("docstring") OTROBOPT::MeasureEvaluation::setDistribution
OTROBOPT_MeasureEvaluation_setDistribution_doc
%feature("docstring") OTROBOPT::MeasureEvaluation::getDistribution
OTROBOPT_MeasureEvaluation_getDistribution_doc
%feature("docstring") OTROBOPT::MeasureEvaluation::setFunction
OTROBOPT_MeasureEvaluation_setFunction_doc
%feature("docstring") OTROBOPT::MeasureEvaluation::getFunction
OTROBOPT_MeasureEvaluation_getFunction_doc

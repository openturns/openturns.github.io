//                                               -*- C++ -*-
/**
 *  @brief Variance measure
 *
 *  Copyright 2005-2026 Airbus-EDF-IMACS-ONERA-Phimeca
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
#ifndef OTROBOPT_VARIANCEMEASURE_HXX
#define OTROBOPT_VARIANCEMEASURE_HXX

#include "otrobopt/MeasureEvaluationImplementation.hxx"

namespace OTROBOPT
{

/**
 * @class VarianceMeasure
 *
 * Variance measure
 */
class OTROBOPT_API VarianceMeasure
  : public MeasureEvaluationImplementation
{
  CLASSNAME

public:
  /** Default constructor */
  VarianceMeasure();

  /** Parameter constructor */
  VarianceMeasure(const OT::Function & function,
                  const OT::Distribution & distribution);

  /** Virtual constructor method */
  VarianceMeasure * clone() const override;

  /** Evaluation */
  OT::Point operator()(const OT::Point & inP) const override;

  /** String converter */
  OT::String __repr__() const override;

  /** Method save() stores the object through the StorageManager */
  virtual void save(OT::Advocate & adv) const override;

  /** Method load() reloads the object from the StorageManager */
  virtual void load(OT::Advocate & adv) override;

private:


}; /* class VarianceMeasure */

} /* namespace OTROBOPT */

#endif /* OTROBOPT_VARIANCEMEASURE_HXX */

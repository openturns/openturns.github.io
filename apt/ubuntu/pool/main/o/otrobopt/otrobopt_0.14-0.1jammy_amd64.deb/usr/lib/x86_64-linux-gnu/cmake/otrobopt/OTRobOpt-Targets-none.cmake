#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otrobopt" for configuration "None"
set_property(TARGET otrobopt APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(otrobopt PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotrobopt.so.0.0.0"
  IMPORTED_SONAME_NONE "libotrobopt.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otrobopt )
list(APPEND _IMPORT_CHECK_FILES_FOR_otrobopt "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libotrobopt.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

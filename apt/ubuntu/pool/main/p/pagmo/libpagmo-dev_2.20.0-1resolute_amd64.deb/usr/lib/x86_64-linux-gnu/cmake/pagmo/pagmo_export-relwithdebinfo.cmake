#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Pagmo::pagmo" for configuration "RelWithDebInfo"
set_property(TARGET Pagmo::pagmo APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Pagmo::pagmo PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "TBB::tbb"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpagmo.so.9.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libpagmo.so.9"
  )

list(APPEND _cmake_import_check_targets Pagmo::pagmo )
list(APPEND _cmake_import_check_files_for_Pagmo::pagmo "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpagmo.so.9.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

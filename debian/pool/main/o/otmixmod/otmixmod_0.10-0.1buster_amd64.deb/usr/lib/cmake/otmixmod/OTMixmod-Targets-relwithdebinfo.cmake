#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otmixmod" for configuration "RelWithDebInfo"
set_property(TARGET otmixmod APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(otmixmod PROPERTIES
  IMPORTED_LINK_INTERFACE_LIBRARIES_RELWITHDEBINFO "OT"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libotmixmod.so.0.0.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libotmixmod.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS otmixmod )
list(APPEND _IMPORT_CHECK_FILES_FOR_otmixmod "${_IMPORT_PREFIX}/lib/libotmixmod.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

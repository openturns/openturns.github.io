%feature("docstring") OTAGRUM::ContinuousBayesianNetwork
"ContinuousBayesianNetwork class represents a copula bayesian network (CBN), that is
a bayesian network parameterized by local conditional copula functions for each
node. The scope of each copula function is the node and its parents.

Available constructor:
    ContinuousBayesianNetwork(*NamedDAG, DistributionCollection*)

Parameters
----------
dag : :class:`~otagrum.NamedDAG`
    The structure of the CBN
jointDistributions : :py:class:`openturns.DistributionCollection`
    Collection of local conditional copula functions

Examples
--------
Create a CBN from a DAG structure and a collection of distributions

>>> import otagrum
>>> import openturns as ot
>>> import pyAgrum as gum
>>> bn = gum.BayesNet.fastPrototype('A->C->B;')
>>> ndag = otagrum.NamedDAG(bn)
>>> jointDistributions = []
>>> for i in range(ndag.getSize()):
...     dim = 1 + ndag.getParents(i).getSize()
...     R = ot.CorrelationMatrix(dim)
...     for j in range(dim):
...         for k in range(j):
...             R[j, k] = 0.8
...     jointDistributions.append(ot.Normal([0.0]*dim, [1.0]*dim, R).getCopula())
>>> cbn = otagrum.ContinuousBayesianNetwork(ndag, jointDistributions)

Draw a sample from the joint distribution encoded by the CBN

>>> sample = cbn.getSample(100)"

// ----------------------------------------------------------------------------

%feature("docstring") OTAGRUM::ContinuousBayesianNetwork::getNamedDAG
"The CBN structure.

Returns
-------
dag : :class:`~otagrum.NamedDAG`
    The underlying NamedDAG"

// ----------------------------------------------------------------------------

%feature("docstring") OTAGRUM::ContinuousBayesianNetwork::setDAGAndDistributionCollection
"Accessor to the DAG and distribution collection.

Parameters
----------
dag : :class:`~otagrum.NamedDAG`
    The underlying NamedDAG
jointDistributions : sequence of :py:class:`openturns.DistributionCollection`
    The collection of local conditional copulas"

// ----------------------------------------------------------------------------

%feature("docstring") OTAGRUM::ContinuousBayesianNetwork::getDistributionCollection
"The collection of local conditional copulas.

Returns
-------
jointDistributions : sequence of :py:class:`openturns.DistributionCollection`
    Collection of local conditional copulas
"

%feature("docstring") OT::GaussianLinearCalibration
"Gaussian linear calibration algorithm (Best Linear Unbiased Estimator or BLUE).

Available constructors:
    GaussianLinearCalibration(*model, inputObservations, outputObservations, candidate, parameterCovariance, errorCovariance, methodName*)

    GaussianLinearCalibration(*modelObservations, gradientObservations, outputObservations, candidate, parameterCovariance, errorCovariance, methodName*)

Parameters
----------
model : :class:`~openturns.Function`
    The parametric function to be calibrated.
inputObservations : 2-d sequence of float
    The sample of input observations.
outputObservations : 2-d sequence of float
    The sample of output observations.
candidate : sequence of float
    The mean of the gaussian prior distribution of the parameter.
parameterCovariance : 2-d sequence of float
    The covariance matrix of the gaussian prior distribution of the parameter.
errorCovariance : 2-d sequence of float
    The covariance matrix of the gaussian distribution of the observations error.
methodName : str
    The name of the least-squares method to use for the calibration. By default, equal to *QR*. Possible values are *SVD*, *QR*, *Cholesky*.
modelObservations : 2-d sequence of float
    The sample of output values of the model.
gradientObservations : 2-d sequence of float
    The Jacobian matrix of the model with respect to the parameter.

Notes
-----
GaussianLinearCalibration is known as the *Best Linear Unbiased Estimator* or *BLUE*. 
It is the minimum variance estimator of the parameter of a given model under 
the assumption that this parameter acts linearly in the model.

The given observation error covariance can be either *local*, ie the same matrix applies for each observation and is of
dimension the output dimension of the model, or *global*, ie the matrix describes
the full set of observation errors, in which case its dimension is the product of
the output dimension of the model and the number of observations.

The prior distribution of the parameter is a :class:`~openturns.Normal`.  

The posterior distribution of the parameter is :class:`~openturns.Normal`. 

The resulting error distribution is :class:`~openturns.Normal` and is based on the 
`errorCovariance` input argument. 

See also
--------
LinearLeastSquaresCalibration, NonLinearLeastSquaresCalibration, GaussianNonLinearCalibration

Examples
--------
Calibrate a nonlinear model using GaussianLinearCalibration:

>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> m = 10
>>> x = [[0.5 + i] for i in range(m)]
>>> inVars = ['a', 'b', 'c', 'x']
>>> formulas = ['a + b * exp(c * x)']
>>> model = ot.SymbolicFunction(inVars, formulas)
>>> p_ref = [2.8, 1.2, 0.5]
>>> params = [0, 1, 2]
>>> modelX = ot.ParametricFunction(model, params, p_ref)
>>> y = modelX(x)
>>> y += ot.Normal(0.0, 0.05).getSample(m)
>>> candidate = [1.0]*3
>>> priorCovariance = ot.CovarianceMatrix(3)
>>> errorCovariance = ot.CovarianceMatrix(1, [0.1])
>>> method = 'SVD'
>>> algo = ot.GaussianLinearCalibration(modelX, x, y, candidate, priorCovariance, errorCovariance, method)
>>> algo.run()
>>> print(algo.getResult().getParameterMAP())
[8.11483,0.0770992,0.992927]"

// ---------------------------------------------------------------------

%feature("docstring") OT::GaussianLinearCalibration::getModelObservations
"Accessor to the model evaluation at the candidate.

Returns
-------
modelObservation : :class:`~openturns.Sample`
    Evaluation of the model at the candidate point."

// ---------------------------------------------------------------------

%feature("docstring") OT::GaussianLinearCalibration::getGradientObservations
"Accessor to the model gradient at the candidate.

Returns
-------
gradientObservation : :class:`~openturns.Matrix`
    Gradient of the model at the candidate point."

// ---------------------------------------------------------------------

%feature("docstring") OT::GaussianLinearCalibration::getCandidate
"Accessor to the parameter candidate.

Returns
-------
candidate : :class:`~openturns.Point`
    Parameter candidate."

// ---------------------------------------------------------------------

%feature("docstring") OT::GaussianLinearCalibration::getParameterCovariance
"Accessor to the parameter prior covariance.

Returns
-------
prior : :class:`~openturns.CovarianceMatrix`
    Parameter prior covariance."

// ---------------------------------------------------------------------

%feature("docstring") OT::GaussianLinearCalibration::getErrorCovariance
"Accessor to the observation error covariance.

Returns
-------
error : :class:`~openturns.CovarianceMatrix`
    Observation error covariance."

// ---------------------------------------------------------------------

%feature("docstring") OT::GaussianLinearCalibration::getGlobalErrorCovariance
"Accessor to the flag for a global observation error covariance.

Returns
-------
flag : bool
    Flag telling if the given observation error covariance is global or not."

// ---------------------------------------------------------------------

%feature("docstring") OT::GaussianLinearCalibration::getMethodName
"Accessor to the name of least-squares method used for the resolution.

Returns
-------
name : :class:`~openturns.String`
    Name of least-squares method used for the resolution."


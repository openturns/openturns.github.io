// Basis docstrings are defined in BasisImplementation_doc.i.in

%feature("docstring") OT::Basis
OT_Basis_doc
%feature("docstring") OT::Basis::build
OT_Basis_build_doc
%feature("docstring") OT::Basis::getDimension
OT_Basis_getDimension_doc
%feature("docstring") OT::Basis::getSize
OT_Basis_getSize_doc
%feature("docstring") OT::Basis::getSubBasis
OT_Basis_getSubBasis_doc
%feature("docstring") OT::Basis::isFinite
OT_Basis_isFinite_doc
%feature("docstring") OT::Basis::isOrthogonal
OT_Basis_isOrthogonal_doc
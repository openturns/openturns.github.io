%define OT_BasisSequence_doc
"Sequence of basis.

Available constructors:
    BasisSequence(*basis*)

    BasisSequence(*basisSeqImp*)

Parameters
----------
basis : a :class:`~openturns.Basis`
    A Basis.
basisSeqImp : BasisSequenceImplementation
    A BasisSequenceImplementation."
%enddef
%feature("docstring") OT::BasisSequenceImplementation
OT_BasisSequence_doc


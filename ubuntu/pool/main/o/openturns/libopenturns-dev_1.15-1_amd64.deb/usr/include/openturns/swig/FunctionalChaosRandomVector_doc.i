%feature("docstring") OT::FunctionalChaosRandomVector
"Functional chaos random vector used to evaluate the Sobol indices.

Available constructors:
    FunctionalChaosRandomVector(functionalChaosResult)

Parameters
----------
functionalChaosResult : :class:`~openturns.FunctionalChaosResult`
    A functional chaos result resulting from a polynomial chaos decomposition.

See also
--------
FunctionalChaosAlgorithm, FunctionalChaosResult

Notes
-----
This structure is created from a FunctionalChaosResult in order to evaluate the
Sobol indices associated to the polynomial chaos decomposition of the model.
"

// ---------------------------------------------------------------------

%feature("docstring") OT::FunctionalChaosRandomVector::getFunctionalChaosResult
"Accessor to the functional chaos result.

Returns
-------
functionalChaosResult : :class:`~openturns.FunctionalChaosResult`
    The functional chaos result resulting from a polynomial chaos decomposition."

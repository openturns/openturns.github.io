%feature("docstring") OT::LinearModelTest::LinearModelFisher
"Test the nullity of the linear regression model coefficients.

**Available usages**:

    LinearModelTest.LinearModelFisher(*firstSample, secondSample*)

    LinearModelTest.LinearModelFisher(*firstSample, secondSample, level*)

    LinearModelTest.LinearModelFisher(*firstSample, secondSample, linearModelResult*)

    LinearModelTest.LinearModelFisher(*firstSample, secondSample, linearModelResult, level*)


Parameters
----------
firstSample : 2-d sequence of float
    First tested sample, of dimension 1.
secondSample : 2-d sequence of float
    Second tested sample, of dimension 1.
linearModelResult : :class:`~openturns.LinearModelResult`
    A linear model. If not provided, it is built using the given samples.
level : positive float :math:`< 1`
    Threshold p-value of the test (= first kind risk), it must be
    :math:`< 1`, equal to 0.05 by default.

Returns
-------
testResult : :class:`~openturns.TestResult`
    Structure containing the result of the test.

See Also
--------
LinearModelTest_LinearModelResidualMean

Notes
-----
The LinearModelTest class is used through its static methods in order to evaluate
the quality of the linear regression model between two samples.
The linear regression model between the
scalar variable :math:`Y` and the :math:`n`-dimensional one
:math:`\\\\vect{X} = (X_i)_{i \\\\leq n}` is as follows:

.. math::

    \\\\tilde{Y} = a_0 + \\\\sum_{i=1}^n a_i X_i + \\\\epsilon

where :math:`\\\\epsilon` is the residual, supposed to follow the standard Normal
distribution.

The LinearModelFisher test checks the nullity of the regression linear model
coefficients (Fisher distribution is used).

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> distribution = ot.Normal()
>>> sample = distribution.getSample(30)
>>> func = ot.SymbolicFunction('x', '2 * x + 1')
>>> firstSample = sample
>>> secondSample = func(sample) + ot.Normal().getSample(30)
>>> test_result = ot.LinearModelTest.LinearModelFisher(firstSample, secondSample)
>>> print(test_result.getPValue())
5.1...e-12
"

// ---------------------------------------------------------------------

%feature("docstring") OT::LinearModelTest::LinearModelResidualMean
"Test zero mean value of the residual of the linear regression model.

**Available usages**:

    LinearModelTest.LinearModelResidualMean(*firstSample, secondSample*)

    LinearModelTest.LinearModelResidualMean(*firstSample, secondSample, level*)

    LinearModelTest.LinearModelResidualMean(*firstSample, secondSample, linearModelResult*)

    LinearModelTest.LinearModelResidualMean(*firstSample, secondSample, linearModelResult, level*)


Parameters
----------
firstSample : 2-d sequence of float
    First tested sample, of dimension 1.
secondSample : 2-d sequence of float
    Second tested sample, of dimension 1.
linearModelResult : :class:`~openturns.LinearModelResult`
    A linear model. If not provided, it is built using the given samples.
level : positive float :math:`< 1`
    Threshold p-value of the test (= first kind risk), it must be
    :math:`< 1`, equal to 0.05 by default.

Returns
-------
testResult : :class:`~openturns.TestResult`
    Structure containing the result of the test.

See Also
--------
LinearModelTest_LinearModelFisher, LinearModelTest_LinearModelHarrisonMcCabe

Notes
-----
The LinearModelTest class is used through its static methods in order to evaluate
the quality of the linear regression model between two samples.
The linear regression model between the
scalar variable :math:`Y` and the :math:`n`-dimensional one
:math:`\\\\vect{X} = (X_i)_{i \\\\leq n}` is as follows:

.. math::

    \\\\tilde{Y} = a_0 + \\\\sum_{i=1}^n a_i X_i + \\\\epsilon

where :math:`\\\\epsilon` is the residual, supposed to follow the standard Normal
distribution.

The LinearModelResidualMean Test checks, under the hypothesis of a gaussian
sample, if the mean of the residual is equal to zero. It is based on the Student
test (equality of mean for two gaussian samples).

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> distribution = ot.Normal()
>>> sample = distribution.getSample(30)
>>> func = ot.SymbolicFunction('x', '2 * x + 1')
>>> firstSample = sample
>>> secondSample = func(sample) + ot.Normal().getSample(30)
>>> test_result = ot.LinearModelTest.LinearModelResidualMean(firstSample, secondSample)
"

// ---------------------------------------------------------------------

%feature("docstring") OT::LinearModelTest::LinearModelHarrisonMcCabe
"Test the homoskedasticity of the linear regression model residuals.

**Available usages**:

    LinearModelTest.LinearModelHarrisonMcCabe(*firstSample, secondSample*)

    LinearModelTest.LinearModelHarrisonMcCabe(*firstSample, secondSample, linearModelResult*)

    LinearModelTest.LinearModelHarrisonMcCabe(*firstSample, secondSample, level, breakPoint, simulationSize*)

    LinearModelTest.LinearModelHarrisonMcCabe(*firstSample, secondSample, linearModelResult, level, breakPoint, simulationSize*)

Parameters
----------
firstSample : 2-d sequence of float
    First tested sample, of dimension 1.
secondSample : 2-d sequence of float
    Second tested sample, of dimension 1.
linearModelResult : :class:`~openturns.LinearModelResult`
    A linear model. If not provided, it is built using the given samples.
level : positive float :math:`< 1`
    Threshold p-value of the test (= first kind risk), it must be
    :math:`< 1`, equal to 0.05 by default.
breakPoint : positive float :math:`< 1`
    Percentage of data to be taken as breakPoint in the variances. It must be
    :math:`< 1`, equal to 0.5 by default.
simulationSize : positive int
    Size of the sample used to compute the p-value. Default is 1000.

Returns
-------
testResult : :class:`~openturns.TestResult`
    Structure containing the result of the test.

See Also
--------
LinearModelTest_LinearModelBreuschPagan, LinearModelTest_LinearModelResidualMean,
LinearModelTest_LinearModelDurbinWatson

Notes
-----
The LinearModelTest class is used through its static methods in order to evaluate
the quality of the linear regression model between two samples.
The linear regression model between the
scalar variable :math:`Y` and the :math:`n`-dimensional one
:math:`\\\\vect{X} = (X_i)_{i \\\\leq n}` is as follows:

.. math::

    \\\\tilde{Y} = a_0 + \\\\sum_{i=1}^n a_i X_i + \\\\epsilon

where :math:`\\\\epsilon` is the residual.

The Harrison-McCabe test checks the heteroskedasticity of the residuals. The
breakpoint in the variances is set by default to the half of the sample. The
p-value is estimed using simulation. If the binary quality measure is false, then
the homoskedasticity hypothesis can be rejected with respect to the given level.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> distribution = ot.Normal()
>>> sample = distribution.getSample(30)
>>> func = ot.SymbolicFunction('x', '2 * x + 1')
>>> firstSample = sample
>>> secondSample = func(sample) + ot.Normal().getSample(30)
>>> test_result = ot.LinearModelTest.LinearModelHarrisonMcCabe(firstSample, secondSample)
>>> print(test_result)
class=TestResult name=Unnamed type=HarrisonMcCabe binaryQualityMeasure=true p-value threshold=0.05 p-value=0.142 statistic=0.373225 description=[]
"

// ---------------------------------------------------------------------

%feature("docstring") OT::LinearModelTest::LinearModelBreuschPagan
"Test the homoskedasticity of the linear regression model residuals.

**Available usages**:

    LinearModelTest.LinearModelBreuschPagan(*firstSample, secondSample*)

    LinearModelTest.LinearModelBreuschPagan(*firstSample, secondSample, linearModelResult*)

    LinearModelTest.LinearModelBreuschPagan(*firstSample, secondSample, level*)

    LinearModelTest.LinearModelBreuschPagan(*firstSample, secondSample, linearModelResult, level*)

Parameters
----------
firstSample : 2-d sequence of float
    First tested sample, of dimension 1.
secondSample : 2-d sequence of float
    Second tested sample, of dimension 1.
linearModelResult : :class:`~openturns.LinearModelResult`
    A linear model. If not provided, it is built using the given samples.
level : positive float :math:`< 1`
    Threshold p-value of the test (= first kind risk), it must be
    :math:`< 1`, equal to 0.05 by default.

Returns
-------
testResult : :class:`~openturns.TestResult`
    Structure containing the result of the test.

See Also
--------
LinearModelTest_LinearModelHarrisonMcCabe, LinearModelTest_LinearModelResidualMean,
LinearModelTest_LinearModelDurbinWatson

Notes
-----
The LinearModelTest class is used through its static methods in order to evaluate
the quality of the linear regression model between two samples.
The linear regression model between the
scalar variable :math:`Y` and the :math:`n`-dimensional one
:math:`\\\\vect{X} = (X_i)_{i \\\\leq n}` is as follows:

.. math::

    \\\\tilde{Y} = a_0 + \\\\sum_{i=1}^n a_i X_i + \\\\epsilon

where :math:`\\\\epsilon` is the residual.

The Breusch-Pagan test checks the heteroskedasticity of the residuals. A linear
regression model is fitted on the squared residuals. The statistic is computed
using the Studendized version with the chi-squared distribution. If the binary
quality measure is false, then the homoskedasticity hypothesis can be rejected
with respect to the given level.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> distribution = ot.Normal()
>>> sample = distribution.getSample(30)
>>> func = ot.SymbolicFunction('x', '2 * x + 1')
>>> firstSample = sample
>>> secondSample = func(sample) + ot.Normal().getSample(30)
>>> test_result = ot.LinearModelTest.LinearModelBreuschPagan(firstSample, secondSample)
>>> print(test_result)
class=TestResult name=Unnamed type=BreuschPagan binaryQualityMeasure=true p-value threshold=0.05 p-value=0.700772 statistic=0.14767 description=[]
"


// ---------------------------------------------------------------------

%feature("docstring") OT::LinearModelTest::LinearModelDurbinWatson
"Test the autocorrelation of the linear regression model residuals.

**Available usages**:

    LinearModelTest.LinearModelDurbinWatson(*firstSample, secondSample*)

    LinearModelTest.LinearModelDurbinWatson(*firstSample, secondSample, hypothesis, level*)

    LinearModelTest.LinearModelDurbinWatson(*firstSample, secondSample, linearModelResult*)

    LinearModelTest.LinearModelDurbinWatson(*firstSample, secondSample, linearModelResult, hypothesis, level*)

Parameters
----------
firstSample : 2-d sequence of float
    First tested sample.
secondSample : 2-d sequence of float
    Second tested sample, of dimension 1.
linearModelResult : :class:`~openturns.LinearModelResult`
    A linear model. If not provided, it is built using the given samples.
hypothesis : str
    Hypothesis H0 for the residuals. It can be : 'Equal' to 0, 'Less' than 0 or
    'Greater' than 0. Default is set to 'Equal' to 0.
level : positive float :math:`< 1`
    Threshold p-value of the test (= first kind risk), it must be
    :math:`< 1`, equal to 0.05 by default.

Returns
-------
testResult : :class:`~openturns.TestResult`
    Structure containing the result of the test.

See Also
--------
LinearModelTest_LinearModelBreuschPagan, LinearModelTest_LinearModelHarrisonMcCabe, LinearModelTest_LinearModelResidualMean

Notes
-----
The LinearModelTest class is used through its static methods in order to evaluate
the quality of the linear regression model between two samples.
The linear regression model between the
scalar variable :math:`Y` and the :math:`n`-dimensional one
:math:`\\\\vect{X} = (X_i)_{i \\\\leq n}` is as follows:

.. math::

    \\\\tilde{Y} = a_0 + \\\\sum_{i=1}^n a_i X_i + \\\\epsilon

where :math:`\\\\epsilon` is the residual.

The Durbin-Watson test checks the autocorrelation of the residuals. It is possible
to test is the autocorrelation is equal to 0, and less or greater than 0. The
p-value is computed using a normal approximation with mean and variance of the
Durbin-Watson test statistic. If the binary quality measure is false, then the
given autocorrelation hypothesis can be rejected with respect to the given level.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> distribution = ot.Normal()
>>> sample = distribution.getSample(30)
>>> func = ot.SymbolicFunction('x', '2 * x + 1')
>>> firstSample = sample
>>> secondSample = func(sample) + ot.Normal().getSample(30)
>>> test_result = ot.LinearModelTest.LinearModelDurbinWatson(firstSample, secondSample)
>>> print(test_result)
class=TestResult name=Unnamed type=DurbinWatson binaryQualityMeasure=true p-value threshold=0.05 p-value=0.653603 statistic=0.448763 description=[H0: auto.cor=0]
"


// ---------------------------------------------------------------------

%feature("docstring") OT::LinearModelTest::PartialRegression
"Test whether two discrete samples are independent.

**Available usages**:

    LinearModelTest.PartialRegression(*firstSample, secondSample, selection*)

    LinearModelTest.PartialRegression(*firstSample, secondSample, selection, level*)


Parameters
----------
firstSample : 2-d sequence of float
    First tested sample, of dimension :math:`n \\\\geq 1`.
secondSample : 2-d sequence of float
    Second tested sample, of dimension 1.
selection : sequence of int, maximum integer value :math:`< n`
    List of indices selecting which subsets of the first sample will successively
    be tested with the second sample through the regression test.
level : positive float :math:`< 1`
    Threshold p-value of the test (= first kind risk), it must be
    :math:`< 1`, equal to 0.05 by default.

Returns
-------
testResults : Collection of :class:`~openturns.TestResult`
    Results for each component of the linear model including intercept.

See Also
--------
LinearModelTest_FullRegression, LinearModelTest_LinearModelFisher

Notes
-----
The Partial Regression Test is used to assess the linearity between a subset of
components of *firstSample* and *secondSample*.
The parameter *selection* enables to select specific subsets of the
*firstSample* to be tested.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> dim = 3
>>> distCol = [ot.Normal()] * dim
>>> S = ot.CorrelationMatrix(dim)
>>> S[0, dim - 1] = 0.99
>>> copula = ot.NormalCopula(S)
>>> distribution = ot.ComposedDistribution(distCol, copula)
>>> sample = distribution.getSample(30)
>>> firstSample = sample[:, :2]
>>> secondSample = sample[:, 2]
>>> selection = [1]
>>> test_result = ot.LinearModelTest.PartialRegression(firstSample, secondSample, selection)
>>> print(test_result[1])
class=TestResult name=Unnamed type=Regression binaryQualityMeasure=true p-value threshold=0.05 p-value=0.579638 statistic=-0.560438 description=[]"


// ---------------------------------------------------------------------

%feature("docstring") OT::LinearModelTest::FullRegression
"Test whether two discrete samples are not linear.

**Available usages**:

    LinearModelTest.FullRegression(*firstSample, secondSample*)

    LinearModelTest.FullRegression(*firstSample, secondSample, level*)


Parameters
----------
firstSample : 2-d sequence of float
    First tested sample, of dimension :math:`n \\\\geq 1`.
secondSample : 2-d sequence of float
    Second tested sample, of dimension 1.
level : positive float :math:`< 1`
    Threshold p-value of the test (= first kind risk), it must be
    :math:`< 1`, equal to 0.05 by default.

Returns
-------
testResults : Collection of :class:`~openturns.TestResult`
    Results for each component of the linear model including intercept.

See Also
--------
LinearModelTest_PartialRegression, LinearModelTest_LinearModelFisher

Notes
-----
The Full Regression Test is used to check the quality of the linear regression
model between two samples: *firstSample* of dimension *n* and *secondSample* of
dimension 1. If *firstSample[i]* is the sample extracted from
*firstSample* (:math:`i^{th}` coordinate of each point of the sample),
FullRegression performs the linear regression test on all
*firstSample[i]* and *secondSample*. The linear regression test tests if the
linear regression model between two scalar samples is not significant.
It is based on the deviation analysis of the regression.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> dim = 3
>>> distCol = [ot.Normal()] * dim
>>> S = ot.CorrelationMatrix(dim)
>>> S[0, dim - 1] = 0.99
>>> copula = ot.NormalCopula(S)
>>> distribution = ot.ComposedDistribution(distCol, copula)
>>> sample = distribution.getSample(30)
>>> firstSample = sample[:, :2]
>>> secondSample = sample[:, 2]
>>> test_result = ot.LinearModelTest.FullRegression(firstSample, secondSample)
>>> print(test_result)
[class=TestResult name=Unnamed type=Regression binaryQualityMeasure=true p-value threshold=0.05 p-value=0.605 statistic=-0.52335 description=[],class=TestResult name=Unnamed type=Regression binaryQualityMeasure=false p-value threshold=0.05 p-value=9.70282e-27 statistic=44.256 description=[],class=TestResult name=Unnamed type=Regression binaryQualityMeasure=true p-value threshold=0.05 p-value=0.11352 statistic=1.63564 description=[]]"



// SWIG file BaseTemplateDefs.i


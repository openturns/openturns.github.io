%define OT_CovarianceModel_doc
"Covariance model.

Base class for covariance models."

%enddef
%feature("docstring") OT::CovarianceModelImplementation
OT_CovarianceModel_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_computeAsScalar_doc
"Compute the covariance function for scalar model.

Available usages:
    computeAsScalar(s, t)

    computeAsScalar(tau)

Parameters
----------
s, t : sequences of float
    Multivariate index :math:`(\\\\vect{s}, \\\\vect{t}) \\\\in \\\\cD \\\\times \\\\cD`
tau : sequence of float
    Multivariate index :math:`\\\\vect{\\\\tau} \\\\in \\\\cD`

Returns
-------
covariance : float
    Covariance.

Notes
-----
The method makes sense only if the dimension of the process is :math:`d=1`.
It evaluates :math:`C(\\\\vect{s}, \\\\vect{t})`.

In the second usage, the covariance model must be stationary. Then we note
:math:`C^{stat}(\\\\vect{\\\\tau})` for :math:`C(\\\\vect{s}, \\\\vect{s}+\\\\vect{\\\\tau})` as
this quantity does not depend on :math:`\\\\vect{s}`."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::computeAsScalar
OT_CovarianceModel_computeAsScalar_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_computeStandardRepresentative_doc
"Compute the standard representative function of the covariance model.

Available usages:
    computeStandardRepresentative(s, t)

    computeStandardRepresentative(tau)

Parameters
----------
s, t : sequences of float
    Multivariate index :math:`(\\\\vect{s}, \\\\vect{t}) \\\\in \\\\cD \\\\times \\\\cD`
tau : float or sequence of float
    Multivariate index :math:`\\\\vect{\\\\tau} \\\\in \\\\cD`

Returns
-------
rho : float
    Correlation model :math:`\\\\rho`


Notes
-----
It evaluates the scalar function 
:math:`\\\\rho\\\\left(\\\\dfrac{\\\\vect{s}}{\\\\theta}, \\\\dfrac{\\\\vect{t}}{\\\\theta}\\\\right)` or 
:math:`\\\\rho\\\\left(\\\\dfrac{\\\\vect{\\\\tau}}{\\\\theta}\\\\right)` if the model is stationary."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::computeStandardRepresentative
OT_CovarianceModel_computeStandardRepresentative_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_discretize_doc
"Discretize the covariance function on a given mesh.

Parameters
----------
meshOrGrid : :class:`~openturns.Mesh` or :class:`~openturns.RegularGrid`
    Mesh or time grid of size :math:`N` associated with the process.

Returns
-------
covarianceMatrix : :class:`~openturns.CovarianceMatrix`
    Covariance matrix :math:`\\\\in \\\\cS_{nd}^+(\\\\Rset)` (if the process is of
    dimension :math:`d`

Notes
-----
This method makes a discretization of the model on *meshOrGrid* composed of
the vertices :math:`(\\\\vect{t}_1, \\\\dots, \\\\vect{t}_{N-1})` and returns the
covariance matrix:

.. math ::

    \\\\mat{C}_{1,\\\\dots,k} = \\\\left(
        \\\\begin{array}{cccc}
        C(\\\\vect{t}_1, \\\\vect{t}_1) &C(\\\\vect{t}_1, \\\\vect{t}_2) & \\\\dots & 
        C(\\\\vect{t}_1, \\\\vect{t}_{k}) \\\\\\\\
        \\\\dots & C(\\\\vect{t}_2, \\\\vect{t}_2)  & \\\\dots & 
        C(\\\\vect{t}_2, \\\\vect{t}_{k}) \\\\\\\\
        \\\\dots & \\\\dots & \\\\dots & \\\\dots \\\\\\\\
        \\\\dots & \\\\dots & \\\\dots & C(\\\\vect{t}_{k}, \\\\vect{t}_{k})
        \\\\end{array} \\\\right)"
%enddef
%feature("docstring") OT::CovarianceModelImplementation::discretize
OT_CovarianceModel_discretize_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_discretizeAndFactorize_doc
"Discretize and factorize the covariance function on a given mesh.

Parameters
----------
meshOrGrid : :class:`~openturns.Mesh` or :class:`~openturns.RegularGrid`
    Mesh or time grid of size :math:`N` associated with the process.

Returns
-------
CholeskyMatrix : :class:`~openturns.TriangularMatrix`
    Cholesky factor of the covariance matrix :math:`\\\\in \\\\cM_{nd\\\\times nd}(\\\\Rset)`
    (if the process is of dimension :math:`d`).

Notes
-----
This method makes a discretization of the model on *meshOrGrid* composed of
the vertices :math:`(\\\\vect{t}_1, \\\\dots, \\\\vect{t}_{N-1})` thanks to the
`discretize` method and returns its Cholesky factor."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::discretizeAndFactorize
OT_CovarianceModel_discretizeAndFactorize_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_discretizeHMatrix_doc
"Discretize the covariance function on a given mesh using HMatrix result.

Parameters
----------
meshOrGrid : :class:`~openturns.Mesh` or :class:`~openturns.RegularGrid`
    Mesh or time grid of size :math:`N` associated with the process.
hmatParam : :class:`~openturns.HMatrixParameters`
    Parameter values for the HMatrix

Returns
-------
HMatrix : :class:`~openturns.HMatrix`
    Covariance matrix :math:`\\\\in\\\\cS_{nd}^+(\\\\Rset)` (if the process is of
    dimension :math:`d`), stored in hierarchical format (H-Matrix)

Notes
-----
This method si similar to the *discretize* method. This method requires that 
OpenTURNS has been compiled with the hmat library.
The method is helpfull for very large parameters (Mesh, grid, Sample) 
as its compress data.
"
%enddef
%feature("docstring") OT::CovarianceModelImplementation::discretizeHMatrix
OT_CovarianceModel_discretizeHMatrix_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_discretizeAndFactorizeHMatrix_doc
"Discretize and factorize the covariance function on a given mesh.

This uses HMatrix.

Parameters
----------
meshOrGrid : :class:`~openturns.Mesh` or :class:`~openturns.RegularGrid`
    Mesh or time grid of size :math:`N` associated with the process.
hmatParam : :class:`~openturns.HMatrixParameters`
    Parameter values for the HMatrix

Returns
-------
HMatrix : :class:`~openturns.HMatrix`
    Cholesk matrix :math:`\\\\in \\\\cS_{nd}^+(\\\\Rset)` (if the process is of
    dimension :math:`d`), stored in hierarchical format (H-Matrix)

Notes
-----
This method si similar to the *discretizeAndFactorize* method. This method 
requires that OpenTURNS has been compiled with the hmat library.
The method is helpfull for very large parameters (Mesh, grid, Sample) 
as its compress data.
"
%enddef
%feature("docstring") OT::CovarianceModelImplementation::discretizeAndFactorizeHMatrix
OT_CovarianceModel_discretizeAndFactorizeHMatrix_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_discretizeRow_doc
"**(TODO)**"
%enddef
%feature("docstring") OT::CovarianceModelImplementation::discretizeRow
OT_CovarianceModel_discretizeRow_doc


// ---------------------------------------------------------------------

%define OT_CovarianceModel_getAmplitude_doc
"Get the amplitude parameter :math:`\\\\vect{\\\\sigma}` of the covariance function.

Returns
-------
amplitude : :class:`~openturns.Point`
    The amplitude parameter :math:`\\\\vect{\\\\sigma} \\\\in \\\\Rset^d` of the covariance 
    function."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getAmplitude
OT_CovarianceModel_getAmplitude_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getOutputDimension_doc
"Get the dimension :math:`d` of the covariance function.

Returns
-------
d : int
    Dimension :math:`d` such that :math:`C : \\\\cD \\\\times \\\\cD \\\\mapsto \\\\cS_d^+(\\\\Rset).`
    This is the dimension of the process :math:`X`."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getOutputDimension
OT_CovarianceModel_getOutputDimension_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_get_marginal
"Get the ith marginal of the model.

Returns
-------
marginal : int or sequence of int
    index of marginal of the model."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getMarginal
OT_CovarianceModel_get_marginal

// ---------------------------------------------------------------------

%define OT_CovarianceModel_get_nugget_factor_doc
"Accessor to the nugget factor.

This parameter allows smooth predictions from noisy data.
The nugget is added to the diagonal of the assumed training covariance
(thanks to discretize) and acts as a Tikhonov regularization in the
problem.

Returns
-------
nuggetFactor : float
    Nugget factor used to model the observation error variance."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getNuggetFactor
OT_CovarianceModel_get_nugget_factor_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getParameter_doc
"Get the parameters of the covariance function.

Returns
-------
parameters : :class:`~openturns.Point`
    List of the scale parameter :math:`\\\\vect{\\\\theta} \\\\in \\\\Rset^n` and the
    amplitude parameter :math:`\\\\vect{\\\\sigma} \\\\in \\\\Rset^d` of the covariance
    function.

   The other specific parameters are not included."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getParameter
OT_CovarianceModel_getParameter_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getParameterDescription_doc
"Get the description of the covariance function parameters.

Returns
-------
descriptionParam : :class:`~openturns.Description`
    Description of the components of the parameters obtained with the
    *getParameter* method.."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getParameterDescription
OT_CovarianceModel_getParameterDescription_doc

// ---------------------------------------------------------------------
%define OT_CovarianceModel_getScale_doc
"Get the scale parameter :math:`\\\\vect{\\\\theta}` of the covariance function.

Returns
-------
scale : :class:`~openturns.Point`
    The scale parameter :math:`\\\\vect{\\\\theta} \\\\in \\\\Rset^n` used in the 
    covariance function."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getScale
OT_CovarianceModel_getScale_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getOutputCorrelation_doc
"Get the spatial correlation matrix :math:`\\\\mat{R}` of the covariance function.

Returns
-------
spatialCorrelation : :class:`~openturns.CorrelationMatrix`
    Correlation matrix :math:`\\\\mat{R} \\\\in \\\\cS_d^+(\\\\Rset)`."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getOutputCorrelation
OT_CovarianceModel_getOutputCorrelation_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getInputDimension_doc
"Get the input dimension :math:`n` of the covariance function.

Returns
-------
inputDimension : int
    Spatial dimension :math:`n` of the covariance function."

%enddef
%feature("docstring") OT::CovarianceModelImplementation::getInputDimension
OT_CovarianceModel_getInputDimension_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_isDiagonal_doc
"Test whether the model is diagonal or not.

Returns
-------
isDiagonal : bool
    *True* if the model is diagonal."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::isDiagonal
OT_CovarianceModel_isDiagonal_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_isStationary_doc
"Test whether the model is stationary or not.

Returns
-------
isStationary : bool
    *True* if the model is stationary.

Notes
-----
The covariance function :math:`C` is stationary when it is invariant by
translation:

.. math::

    \\\\forall(\\\\vect{s},\\\\vect{t},\\\\vect{h}) \\\\in \\\\cD \\\\times \\\\cD, & \\\\, \\\\quad
    C(\\\\vect{s}, \\\\vect{s}+\\\\vect{h}) = C(\\\\vect{t}, \\\\vect{t}+\\\\vect{h})


We note :math:`C^{stat}(\\\\vect{\\\\tau})` for :math:`C(\\\\vect{s}, \\\\vect{s}+\\\\vect{\\\\tau})`."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::isStationary
OT_CovarianceModel_isStationary_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_partialGradient_doc
"Compute the gradient of the covariance function.

Parameters
----------
s, t : floats or sequences of float
    Multivariate index :math:`(\\\\vect{s}, \\\\vect{t}) \\\\in \\\\cD \\\\times \\\\cD`.

Returns
-------
gradient : :class:`~openturns.Matrix`
    Gradient of the covariance function."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::partialGradient
OT_CovarianceModel_partialGradient_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_parameterGradient_doc
"Compute the gradient according to the parameters.

Parameters
----------
s, t : sequences of float
    Multivariate index :math:`(\\\\vect{s}, \\\\vect{t}) \\\\in \\\\cD \\\\times \\\\cD`.

Returns
-------
gradient : :class:`~openturns.Matrix`
    Gradient of the function according to the parameters."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::parameterGradient
OT_CovarianceModel_parameterGradient_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_setAmplitude_doc
"Set the amplitude parameter :math:`\\\\vect{\\\\sigma}` of the covariance function.

Parameters
----------
amplitude : :class:`~openturns.Point`
    The amplitude parameter :math:`\\\\vect{\\\\sigma} \\\\in \\\\Rset^d` to be used in the
    covariance function. 
    Its size must be equal to the dimension of the covariance function."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::setAmplitude
OT_CovarianceModel_setAmplitude_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_setScale_doc
"Set the scale parameter :math:`\\\\vect{\\\\theta}` of the covariance function.

Parameters
----------
scale : :class:`~openturns.Point`
    The scale parameter :math:`\\\\vect{\\\\theta} \\\\in \\\\Rset^n` to be used in the
    covariance function.
    Its size must be equal to the input dimension of the covariance function."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::setScale
OT_CovarianceModel_setScale_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_set_nugget_factor_doc
"Set the nugget factor for the variance of the observation error.

Acts on the discretized covariance matrix.

Parameters
----------
nuggetFactor : float
    nugget factor to be used to model the variance of the observation error."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::setNuggetFactor
OT_CovarianceModel_set_nugget_factor_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_setParameter_doc
"Set the parameters of the covariance function.

Parameters
----------
parameters : :class:`~openturns.Point`
    List of the scale parameter :math:`\\\\vect{\\\\theta} \\\\in \\\\Rset^n` and the
    amplitude parameter :math:`\\\\vect{\\\\sigma} \\\\in \\\\Rset^d` of the covariance
    function.

    Must be of dimension :math:`n+d`."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::setParameter
OT_CovarianceModel_setParameter_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_setOutputCorrelation_doc
"Set the spatial correlation matrix :math:`\\\\mat{R}` of the covariance function.

Parameters
----------
spatialCorrelation : :class:`~openturns.CorrelationMatrix`
    Correlation matrix :math:`\\\\mat{R} \\\\in \\\\cS_d^+([-1,1])`."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::setOutputCorrelation
OT_CovarianceModel_setOutputCorrelation_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_operator_doc
"Evaluate the covariance function.

Available usages:
    __call__(s, t)

    __call__(tau)

Parameters
----------
s, t : floats or sequences of float
    Multivariate index :math:`(\\\\vect{s}, \\\\vect{t}) \\\\in \\\\cD \\\\times \\\\cD`.
tau : float or sequence of float
    Multivariate index :math:`\\\\vect{\\\\tau} \\\\in \\\\cD`.

Returns
-------
covariance : CovarianceMatrix
    The evaluation of the covariance function."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::operator()
OT_CovarianceModel_operator_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_setActiveParameter_doc
"Accessor to the active parameter set.

Parameters
----------
active : sequence of int
    Indices of the active parameters."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::setActiveParameter
OT_CovarianceModel_setActiveParameter_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getActiveParameter_doc
"Accessor to the active parameter set.

Returns
-------
active : :class:`~openturns.Indices`
    Indices of the active parameters."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getActiveParameter
OT_CovarianceModel_getActiveParameter_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_draw_doc
"Draw a specific component of the covariance model with input dimension 1.

Parameters
----------
rowIndex : int, :math:`0 \\\\leq rowIndex < dimension`
    The row index of the component to draw. Default value is 0.
columnIndex: int, :math:`0 \\\\leq columnIndex < dimension`
    The column index of the component to draw. Default value is 0.
tMin : float
    The lower bound of the range over which the model is plotted. Default value is *CovarianceModel-DefaultTMin* in :class:`~openturns.ResourceMap`.
tMax : float
    The upper bound of the range over which the model is plotted. Default value is *CovarianceModel-DefaultTMax* in :class:`~openturns.ResourceMap`.
pointNumber : int, :math:`pointNumber \\\\geq 2`
    The discretization of the range :math:`[tMin,tMax]` over which the model is plotted. Default value is *CovarianceModel-DefaultPointNumber* in  class:`~openturns.ResourceMap`.
asStationary : bool
    Flag to tell if the model has to be plotted as a stationary model, ie as a function of the lag :math:`\\\\tau=t-s` if equals to *True*, or as a non-stationary model, ie as a function of :math:`(s,t)` if equals to *False*. Default value is *True*.
correlationFlag : bool
    Flag to tell if the model has to be plotted as a correlation function if equals to *True* or as a covariance function if equals to *False*. Default value is *False*.

Returns
-------
graph : :class:`~openturns.Graph`
    A graph containing a unique curve if *asStationary=True* and if the model is actually a stationary model, or containing the iso-values of the model if *asStationary=False* or if the model is nonstationary.

"
%enddef
%feature("docstring") OT::CovarianceModelImplementation::draw
OT_CovarianceModel_draw_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_setFullParameter_doc
"Set the full parameters of the covariance function.

Parameters
----------
parameter : :class:`~openturns.Point`
    List the full parameter of the covariance function i.e.
    scale parameter :math:`\\\\vect{\\\\theta} \\\\in \\\\Rset^n`, the
    the amplitude parameter :math:`\\\\vect{\\\\sigma} \\\\in \\\\Rset^d`,
    the Spatial correlation parameter  :math:`\\\\mat{R} \\\\in \\\\cS_d^+([-1,1])`;
    and potential other parameter depending on the model;

    Must be at least of dimension :math:`n+\\\\frac{d(d+1)}{2}`."
%enddef
%feature("docstring") OT::CovarianceModelImplementation::setFullParameter
OT_CovarianceModel_setFullParameter_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getFullParameter_doc
"Get the full parameters of the covariance function.

Returns
-------
parameter : :class:`~openturns.Point`
    List the full parameter of the covariance function i.e.
    scale parameter :math:`\\\\vect{\\\\theta} \\\\in \\\\Rset^n`, the
    the amplitude parameter :math:`\\\\vect{\\\\sigma} \\\\in \\\\Rset^d`,
    the Spatial correlation parameter  :math:`\\\\mat{R} \\\\in \\\\cS_d^+([-1,1])`;
    and potential other parameter depending on the model;
"
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getFullParameter
OT_CovarianceModel_getFullParameter_doc

// ---------------------------------------------------------------------

%define OT_CovarianceModel_getFullParameterDescription_doc
"Get the description full parameters of the covariance function.

Returns
-------
description : :class:`~openturns.Description`
    Description of the full parameter of the covariance function.
"
%enddef
%feature("docstring") OT::CovarianceModelImplementation::getFullParameterDescription
OT_CovarianceModel_getFullParameterDescription_doc


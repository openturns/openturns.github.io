%feature("docstring") OT::VonMises
"von Mises distribution.

Parameters
----------
mu : float
    Mean parameter
kappa : float, :math:`\\\\kappa > 0`
    Concentration parameter

Notes
-----
Its probability density function is defined as:

.. math::

    f_X(x) = \\\\frac{e^{\\\\kappa\\\\cos(x-\\\\mu)}}
                  {2\\\\pi \\\\mathrm{I}_0(\\\\kappa)}, \\\\quad x \\\\in [\\\\mu-\\\\pi, \\\\mu+\\\\pi]

with :math:`\\\\kappa > 0` and :math:`\\\\mathrm{I}_0` the modified Bessel function of order 0.

Examples
--------
Create a distribution:

>>> import openturns as ot
>>> distribution = ot.VonMises(1.0, 2.0)

Draw a sample:

>>> sample = distribution.getSample(5)"

// ---------------------------------------------------------------------

%feature("docstring") OT::VonMises::getMu
"Accessor to the location parameter.

Returns
-------
mu : float
    Mean parameter."

// ---------------------------------------------------------------------

%feature("docstring") OT::VonMises::setMu
"Accessor to the location parameter.

Parameters
----------
mu : float
    Mean parameter."

// ---------------------------------------------------------------------

%feature("docstring") OT::VonMises::getKappa
"Accessor to the concentration parameter.

Returns
-------
kappa : float
    Concentration parameter."

// ---------------------------------------------------------------------

%feature("docstring") OT::VonMises::setKappa
"Accessor to the concentration parameter.

Parameters
----------
kappa : float, :math:`\\\\kappa > 0`
    Concentration parameter."

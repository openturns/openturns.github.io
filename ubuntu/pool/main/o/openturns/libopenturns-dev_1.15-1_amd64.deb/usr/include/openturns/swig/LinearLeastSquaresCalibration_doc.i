%feature("docstring") OT::LinearLeastSquaresCalibration
"Linear least squares calibration algorithm.

Available constructors:
    LinearLeastSquaresCalibration(*model, inputObservations, outputObservations, candidate, methodName*)

    LinearLeastSquaresCalibration(*modelObservations, gradientObservations, outputObservations, candidate, methodName*)

Parameters
----------
model : :class:`~openturns.Function`
    The parametric function to be calibrated.
inputObservations : 2-d sequence of float
    The sample of input observations.
outputObservations : 2-d sequence of float
    The sample of output observations.
candidate : sequence of float
    The reference value of the parameter.
methodName : str
    The name of the least-squares method to use for the calibration. By default, equal to *QR*. Possible values are *SVD*, *QR*, *Cholesky*.

Notes
-----
LinearLeastSquaresCalibration is the minimum variance estimator of the parameter of a given model under the assumption that this parameter acts linearly in the model.

The prior distribution of the parameter is a :class:`~openturns.Dirac`. 

The posterior distribution of the parameter is :class:`~openturns.Normal` and reflects the 
variability of the optimum parameter depending on the observation sample. 
The associated covariance matrix may be regularized depending on the value of the 
key `LinearLeastSquaresCalibration-Regularization` in the :class:`~openturns.ResourceMap`. 
Let us denote by :math:`s_1` the smallest singular value of the covariance matrix. 
The default value of the `LinearLeastSquaresCalibration-Regularization`, zero, 
ensures that the singular values of the covariance matrix are left unmodified.  
If this parameter is set to a nonzero, relatively small, value denoted by :math:`\\\\epsilon`, 
then all singular values of the covariance matrix are increased by :math:`\\\\epsilon s_1`. 

The resulting distribution of the output error is :class:`~openturns.Normal` with a zero mean 
and a diagonal covariance matrix computed from the residuals. 
The residuals are computed based on the linearization of the model, 
where the Jacobian matrix is evaluated at the candidate point. 
The diagonal of the diagonal covariance matrix of the output error 
is contant and is estimated with the unbiased variance estimator. 

See also
--------
GaussianLinearCalibration, NonLinearLeastSquaresCalibration, GaussianNonLinearCalibration

Examples
--------
Calibrate a nonlinear model using linear least-squares:

>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> m = 10
>>> x = [[0.5 + i] for i in range(m)]
>>> inVars = ['a', 'b', 'c', 'x']
>>> formulas = ['a + b * exp(c * x)']
>>> model = ot.SymbolicFunction(inVars, formulas)
>>> p_ref = [2.8, 1.2, 0.5]
>>> params = [0, 1, 2]
>>> modelX = ot.ParametricFunction(model, params, p_ref)
>>> y = modelX(x)
>>> y += ot.Normal(0.0, 0.05).getSample(m)
>>> candidate = [1.0]*3
>>> method = 'SVD'
>>> algo = ot.LinearLeastSquaresCalibration(modelX, x, y, candidate, method)
>>> algo.run()
>>> print(algo.getResult().getParameterMAP())
[8.24019,0.0768046,0.992957]"

// ---------------------------------------------------------------------

%feature("docstring") OT::LinearLeastSquaresCalibration::getModelObservations
"Accessor to the model evaluation at the candidate.

Returns
-------
modelObservation : :class:`~openturns.Sample`
    Evaluation of the model at the candidate point."

// ---------------------------------------------------------------------

%feature("docstring") OT::LinearLeastSquaresCalibration::getGradientObservations
"Accessor to the model gradient at the candidate.

Returns
-------
gradientObservation : :class:`~openturns.Matrix`
    Gradient of the model at the candidate point."

// ---------------------------------------------------------------------

%feature("docstring") OT::LinearLeastSquaresCalibration::getCandidate
"Accessor to the parameter candidate.

Returns
-------
candidate : :class:`~openturns.Point`
    Parameter candidate."

// ---------------------------------------------------------------------

%feature("docstring") OT::LinearLeastSquaresCalibration::getMethodName
"Accessor to the name of least-squares method used for the resolution.

Returns
-------
name : :class:`~openturns.String`
    Name of least-squares method used for the resolution."


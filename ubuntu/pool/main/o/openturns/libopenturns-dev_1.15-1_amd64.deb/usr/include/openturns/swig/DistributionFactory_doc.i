// DistributionFactory docstrings are defined in DistributionFactory_doc.i.in

%feature("docstring") OT::DistributionFactory
OT_DistributionFactory_doc
%feature("docstring") OT::DistributionFactory::build
OT_DistributionFactory_build_doc
%feature("docstring") OT::DistributionFactory::buildEstimator
OT_DistributionFactory_buildEstimator_doc
%feature("docstring") OT::DistributionFactory::getBootstrapSize
OT_DistributionFactory_getBootstrapSize_doc
%feature("docstring") OT::DistributionFactory::setBootstrapSize
OT_DistributionFactory_setBootstrapSize_doc

// ---------------------------------------------------------------------

%feature("docstring") OT::DistributionFactory::GetContinuousMultiVariateFactories
"Accessor to the list of continuous multivariate factories.

Returns
-------
listFactories : collection of :class:`~openturns.DistributionFactory`
    All the valid continuous multivariate factories."

// ---------------------------------------------------------------------

%feature("docstring") OT::DistributionFactory::GetContinuousUniVariateFactories
"Accessor to the list of continuous univariate factories.

Returns
-------
listFactories : collection of :class:`~openturns.DistributionFactory`
    All the valid continuous univariate factories."

// ---------------------------------------------------------------------

%feature("docstring") OT::DistributionFactory::GetDiscreteMultiVariateFactories
"Accessor to the list of discrete multivariate factories.

Returns
-------
listFactories : collection of :class:`~openturns.DistributionFactory`
    All the valid discrete multivariate factories."

// ---------------------------------------------------------------------

%feature("docstring") OT::DistributionFactory::GetDiscreteUniVariateFactories
"Accessor to the list of discrete univariate factories.

Returns
-------
listFactories : collection of :class:`~openturns.DistributionFactory`
    All the valid discrete univariate factories."

// ---------------------------------------------------------------------

%feature("docstring") OT::DistributionFactory::GetMultiVariateFactories
"Accessor to the list of multivariate factories.

Returns
-------
listFactories : collection of :class:`~openturns.DistributionFactory`
    All the valid multivariate factories."

// ---------------------------------------------------------------------

%feature("docstring") OT::DistributionFactory::GetUniVariateFactories
"Accessor to the list of univariate factories.

Returns
-------
listFactories : collection of :class:`~openturns.DistributionFactory`
    All the valid univariate factories."


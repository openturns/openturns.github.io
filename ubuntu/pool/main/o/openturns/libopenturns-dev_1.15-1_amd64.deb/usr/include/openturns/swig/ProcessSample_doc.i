// ProcessSample docstrings are defined in ProcessSampleImplementation_doc.i.in

%feature("docstring") OT::ProcessSample
OT_ProcessSample_doc
%feature("docstring") OT::ProcessSample::add
OT_ProcessSample_add_doc
%feature("docstring") OT::ProcessSample::computeMean
OT_ProcessSample_computeMean_doc
%feature("docstring") OT::ProcessSample::computeSpatialMean
OT_ProcessSample_computeSpatialMean_doc
%feature("docstring") OT::ProcessSample::computeTemporalMean
OT_ProcessSample_computeTemporalMean_doc
%feature("docstring") OT::ProcessSample::computeQuantilePerComponent
OT_ProcessSample_computeQuantilePerComponent_doc
%feature("docstring") OT::ProcessSample::getSize
OT_ProcessSample_getSize_doc
%feature("docstring") OT::ProcessSample::getMesh
OT_ProcessSample_getMesh_doc
%feature("docstring") OT::ProcessSample::getTimeGrid
OT_ProcessSample_getTimeGrid_doc
%feature("docstring") OT::ProcessSample::getDimension
OT_ProcessSample_getDimension_doc
%feature("docstring") OT::ProcessSample::getMarginal
OT_ProcessSample_getMarginal_doc
%feature("docstring") OT::ProcessSample::drawMarginal
OT_ProcessSample_drawMarginal_doc

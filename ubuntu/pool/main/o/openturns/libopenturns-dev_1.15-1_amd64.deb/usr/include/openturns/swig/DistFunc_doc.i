%feature("docstring") OT::DistFunc::logdBinomial
"Logarithm of the probability function of a binomial distribution.

Parameters
----------
n : int, :math:`n>0`
    The number of trials
p : float, :math:`0\\\\leq p\\\\leq 1`
    The success probability of each trial
k : int
    The number of success.

Returns
-------
logp : float
    The natural logarithm of the probability to get :math:`k` successes.

Notes
-----
This method implements Loader's algorithm, the *fast* and *accurate* method
described in [loader2000]_, with the further improvements mentioned
in [dimitriadis2016]_.

Examples
--------
>>> import openturns as ot
>>> p = ot.DistFunc.logdBinomial(5, 0.2, 2)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::dBinomial
"Probability function of a binomial distribution.

Parameters
----------
n : int, :math:`n>0`
    The number of trials
p : float, :math:`0\\\\leq p\\\\leq 1`
    The success probability of each trial
k : int
    The number of success.

Returns
-------
probability : float
    The probability to get :math:`k` successes.

Notes
-----
This method implements Loader's algorithm, the *fast* and *accurate* method
described in [loader2000]_, with the further improvements mentioned
in [dimitriadis2016]_.

Examples
--------
>>> import openturns as ot
>>> p = ot.DistFunc.dBinomial(5, 0.2, 2)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::rBinomial
"Realization of a binomial distribution.

Parameters
----------
n : int, :math:`n>0`
    The number of trials
p : float, :math:`0\\\\leq p\\\\leq 1`
    The success probability of each trial
size : int
    The number of realizations to generate.

Returns
-------
realizations : int or :class:`~openturns.Indices`
    The realizations of the discrete disctribution.

Notes
-----
This method implements the rejection algorithm described in [hormann1993]_.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> r = ot.DistFunc.rBinomial(5, 0.3)
>>> r = ot.DistFunc.rBinomial(5, 0.3, 10)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::rDiscrete
"Realization of a bounded integral discrete distribution.

Parameters
----------
probabilities : sequence of float
    The probabilities of the discrete distribution :math:`p_k=\\\\Prob{X=k}`,
    where :math:`p_k\\\\in[0,1]` and :math:`\\\\sum_{k=1}^n p_k=1`.
size : int
    The number of realizations to generate.

Returns
-------
realizations : int or :class:`~openturns.Indices`
    The realizations of the discrete disctribution.

Notes
-----
This method implements the *alias* method as described in [devroye1986]_,
Chapter 3. It has an optimal space complexity of :math:`\\\\cO(n)` and runtime CPU
complexity of :math:`\\\\cO(1)`.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> r = ot.DistFunc.rDiscrete([0.2, 0.3, 0.5])
>>> r = ot.DistFunc.rDiscrete([0.2, 0.3, 0.5], 10)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::logdHypergeometric
"Logarithm of the probability function of an hypergeometric distribution.

Parameters
----------
n : int, :math:`n\\\\geq 0`
    The population size
k : int, :math:`0\\\\leq k\\\\leq n`
    The number of candidates in the population
m : int, :math:`0\\\\leq m\\\\leq n`
    The number of individuals in a draw
x : int, :math:`x\\\\geq 0`
    The number of candidates in a draw

Returns
-------
logp : float
    The natural logarithm of the probability to get :math:`x` candidates in a draw.

Notes
-----
This method is based on an algorithm similar to Loader's algorithm, the *fast*
and *accurate* method described in [loader2000]_, with the further improvements
mentioned in [dimitriadis2016]_.

Examples
--------
>>> import openturns as ot
>>> p = ot.DistFunc.logdHypergeometric(10, 4, 7, 2)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::dHypergeometric
"The probability function of an hypergeometric distribution.

Parameters
----------
n : int, :math:`n\\\\geq 0`
    The population size
k : int, :math:`0\\\\leq k\\\\leq n`
    The number of candidates in the population
m : int, :math:`0\\\\leq m\\\\leq n`
    The number of individuals in a draw
x : int, :math:`x\\\\geq 0`
    The number of candidates in a draw

Returns
-------
p : float
    The probability to get :math:`x` candidates in a draw.

Notes
-----
This method is based on an algorithm similar to Loader's algorithm, the *fast*
and *accurate* method described in [loader2000]_, with the further improvements
mentioned in [dimitriadis2016]_.

Examples
--------
>>> import openturns as ot
>>> p = ot.DistFunc.dHypergeometric(10, 4, 7, 2)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::pHypergeometric
"The cumulative probability function of an hypergeometric distribution.

Parameters
----------
n : int, :math:`n\\\\geq 0`
    The population size
k : int, :math:`0\\\\leq k\\\\leq n`
    The number of candidates in the population
m : int, :math:`0\\\\leq m\\\\leq n`
    The number of individuals in a draw
x : int, :math:`x\\\\geq 0`
    The number of candidates in a draw
tail : bool
    Flag to tell if it is the CDF or its complement which is evaluated

Returns
-------
p : float
    The probability to get at most :math:`x` candidates in a draw.

Notes
-----
This method is based on a summation of the probability function toward the upper
bound or the lower bound of the range depending on the position of :math:`x` wrt
the mode :math:`\\\\left\\\\lfloor\\\\dfrac{(k+1)(m+1)}{n+2}\\\\right\\\\rfloor` of the
distribution, then take the complement if needed.

Examples
--------
>>> import openturns as ot
>>> p = ot.DistFunc.pHypergeometric(10, 4, 7, 2)
>>> p = ot.DistFunc.pHypergeometric(10, 4, 7, 2, True)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::rHypergeometric
"Realization of an hypergeometric distribution.

Parameters
----------
n : int, :math:`n\\\\geq 0`
    The population size
k : int, :math:`0\\\\leq k\\\\leq n`
    The number of candidates in the population
m : int, :math:`0\\\\leq m\\\\leq n`
    The number of individuals in a draw
size : int
    The number of realizations to generate.

Returns
-------
realizations : int or :class:`~openturns.Indices`
    The realizations of the discrete disctribution.

Notes
-----
This method is based on the alias method.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> r = ot.DistFunc.rHypergeometric(10, 4, 7)
>>> r = ot.DistFunc.rHypergeometric(10, 4, 7, 10)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::pNormal
"CDF of an unit-variance centered Normal distribution.

Parameters
----------
x : float
    Location
tail : bool, default=False
    Tail flag

Returns
-------
cdf : float

Examples
--------
>>> import openturns as ot
>>> cdf = ot.DistFunc.pNormal(0.9)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::qNormal
"Quantile of an unit-variance centered Normal distribution.

Parameters
----------
prob : float

Returns
-------
q : float

Examples
--------
>>> import openturns as ot
>>> q = ot.DistFunc.qNormal(0.95)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::rNormal
"Realization of an unit-variance centered Normal distribution.

Returns
-------
realization : float

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> r = ot.DistFunc.rNormal()"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::kFactorPooled
"Exact margin factor for bilateral covering interval of pooled Normal populations.

Parameters
----------
n : int
    The size of the population

m : int
    The size of the pool

p : float :math:`0<p<1`
    The probability level of the covering interval

alpha : float :math:`0<\\\\alpha<1`
    The confidence level of the covering interval

Returns
-------
k : float
    The margin factor

Notes
-----
This method allows to compute the *exact* margin factor :math:`k` of a
pool of :math:`m` Normal populations of size :math:`n` with unknown
means :math:`\\\\mu_i` and unknown common variance :math:`\\\\sigma^2`.
Let :math:`m_i=\\\\dfrac{1}{n}\\\\sum_{j=1}^nX_{ij}` be the empirical mean
of the ith population :math:`(X_{i1},\\\\dots,X_{in})` and
:math:`\\\\sigma^2_{mn}=\\\\dfrac{}{}\\\\sum_{i=1}^m\\\\sum_{j=1}^n(X_{ij}-m_i)^2`
the empirical *pooled* variance. The covering factor :math:`k` is such
that the intervals :math:`[m_i-k\\\\sigma_{mn},m_i+k\\\\sigma_{mn}]` satisfy:

.. math::
    \\\\Prob{\\\\Prob{X_i\\\\in[m_i-k\\\\sigma_{mn},m_i+k\\\\sigma_{mn}]}\\\\geq p}=\\\\alpha

for :math:`i\\\\in\\\\{1,\\\\dots,m\\\\}`. It reduces to find :math:`k` such that:

.. math::
    \\\\int_{\\\\Rset}F(x,k;\\\\nu_{m,n},p)\\\\phi_{0,1/\\\\sqrt{n}}(x)\\\\,\\\\di x = \\\\alpha

where :math:`phi_{0,1/\\\\sqrt{n}}` is the density function of the normal
distribution with a mean equals to 0 and a variance equals to
:math:`1/n`, :math:`\\\\nu_{m,n}=m(n-1)` and :math:`F(x,k;\\\\nu_{m,n},p)`
the function defined by:

.. math::
    F(x,k;\\\\nu_{m,n},p)=\\\\bar{F}_{\\\\chi^2_{\\\\nu_{m,n}}}(\\\\nu_{m,n} R^2(x;p)/k^2)

where :math:`\\\\bar{F}_{\\\\chi^2_{\\\\nu_{m,n}}}` is the complementary distribution
function of a chi-square distribution with :math:`\\\\nu_{m,n}` degrees
of freedom and :math:`R(x;p)` the solution of:

.. math::
    \\\\Phi(x + R) - \\\\Phi(x - R) = p

Examples
--------
>>> import openturns as ot
>>> k = ot.DistFunc.kFactorPooled(5, 3, 0.95, 0.9)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::kFactor
"Exact margin factor for bilateral covering interval of a Normal population.

Parameters
----------
n : int
    The size of the population

p : float :math:`0<p<1`
    The probability level of the covering interval

alpha : float :math:`0<\\\\alpha<1`
    The confidence level of the covering interval

Returns
-------
k : float
    The margin factor

Notes
-----
This method allows to compute the *exact* margin factor :math:`k` of a
Normal population of size :math:`n` with unknown
means :math:`\\\\mu_i` and unknown common variance :math:`\\\\sigma^2`. It
is equivalent to the pooled version with :math:`m=1`.

Examples
--------
>>> import openturns as ot
>>> k = ot.DistFunc.kFactor(5, 0.95, 0.9)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::pPearsonCorrelation
"Asymptotic probability function for the Pearson :math:`\\\\rho` correlation.

Parameters
----------
n : int
    The size of the population

rho : float :math:`-1<rho<1`
    The Pearson correlation coefficient

tail : bool
    Tells if we consider to be in the critical region (tTrue)
    Default value is False

Returns
-------
pvalue : float
    The probability to be in the region of interest

Notes
-----
This method allows to compute the *asymptotic* distribution of the
`Pearson` correlation coefficient issued from two univariate samples
of size `n`. Basically, we want to measure how coefficient is significatly
different from `0`. If `tail` is True, the issued value measures probability
to be in the critical region.

Examples
--------
>>> import openturns as ot
>>> pval = ot.DistFunc.pPearsonCorrelation(100, 0.3, True)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::logdPoisson
"Logarithm of the probability function of a Poisson distribution.

Parameters
----------
lambda: float, :math:`\\\\lambda\\\\geq 0`
    The intensity of the Poisson distribution
k : int
    The number of success.

Returns
-------
logp : float
    The natural logarithm of the probability to get :math:`k` successes.

Notes
-----
This method implements Loader's algorithm, the *fast* and *accurate* method
described in [loader2000]_, with the further improvements mentioned
in [dimitriadis2016]_.

Examples
--------
>>> import openturns as ot
>>> p = ot.DistFunc.logdPoisson(5.0, 2)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::dPoisson
"Probability function of a Poisson distribution.

Parameters
----------
lambda: float, :math:`\\\\lambda\\\\geq 0`
    The intensity of the Poisson distribution
k : int
    The number of success.

Returns
-------
p : float
    The probability to get :math:`k` successes.

Notes
-----
This method implements Loader's algorithm, the *fast* and *accurate* method
described in [loader2000]_, with the further improvements mentioned
in [dimitriadis2016]_.

Examples
--------
>>> import openturns as ot
>>> p = ot.DistFunc.dPoisson(5.0, 2)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::rPoisson
"Realization of a Poisson distribution.

Parameters
----------
lambda: float, :math:`\\\\lambda\\\\geq 0`
    The intensity of the Poisson distribution
size : int
    The number of realizations to generate.

Returns
-------
realizations : int or :class:`~openturns.Indices`
    The realizations of the discrete disctribution.

Notes
-----
For the small values of :math:`\\\\lambda`, we use the method of inversion by
sequential search described in [devroye1986]_ and with the important errata in
[devroye1986b]_. For the large values of :math:`\\\\lambda`, we use the ratio of
uniform method described in [stadlober1990]_.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> r = ot.DistFunc.rPoisson(5.0)
>>> r = ot.DistFunc.rPoisson(5.0, 10)"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::dNonCentralChiSquare
"Probability function of a NonCentralChiSquare distribution.

Parameters
----------
nu : float
lambda : float
x : float
precision : float, optional
maximum_iteration : int, optional

Returns
-------
p : float"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::dNonCentralStudent
"Probability function of a NonCentralStudent distribution.

Parameters
----------
nu : float
delta : float
x : float

Returns
-------
p : float"

// ---------------------------------------------------------------------

%feature("docstring") OT::DistFunc::eZ1
"Expectation of the min of n independent standard normal random variables.

Parameters
----------
n : int

Returns
-------
mu : float"

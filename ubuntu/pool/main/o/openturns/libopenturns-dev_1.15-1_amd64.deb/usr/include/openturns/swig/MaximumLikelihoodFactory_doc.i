%feature("docstring") OT::MaximumLikelihoodFactory
"Maximum likelihood factory.

Refer to :ref:`maximum_likelihood`.

Parameters
----------
distribution : :class:`~openturns.Distribution`
    The distribution defining the parametric model :math:`p_{\\\\vect{\\\\theta}}` to be adjusted to data.

Notes
-----
Implements generic maximum likelihood estimation.

Let us denote :math:`(\\\\vect{x}_1, \\\\dots, \\\\vect{x}_n)` the sample, :math:`p_{\\\\vect{\\\\theta}}`
the particular distribution of probability density function we want to fit to the sample,
and :math:`\\\\vect{\\\\theta} \\\\in \\\\Theta \\\\in \\\\Rset^p` its the parameter vector.


The likelihood of the sample according to :math:`p_{\\\\vect{\\\\theta}}` is:

.. math::

    likelihood(\\\\vect{x}_1, \\\\dots, \\\\vect{x}_n,\\\\vect{\\\\theta}) = \\\\prod_{i=1}^n p_{\\\\vect{\\\\theta}}(\\\\vect{x}_i)

The parameters :math:`\\\\vect{\\\\theta}` are numerically optimized using an optimization algorithm:

.. math::

    \\\\max_{\\\\vect{\\\\theta} \\\\in \\\\Theta} \\\\log likelihood\\\\, (\\\\vect{x}_1, \\\\dots, \\\\vect{x}_n,\\\\vect{\\\\theta}) = \\\\max_{\\\\vect{\\\\theta} \\\\in \\\\Theta} \\\\sum_{i=1}^n log(p_{\\\\vect{\\\\theta}}(\\\\vect{x}_i))

See also
--------
DistributionFactory

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> distribution = ot.Normal(0.9, 1.7)
>>> sample = distribution.getSample(10)
>>> factory = ot.MaximumLikelihoodFactory(ot.Normal())
>>> inf_distribution = factory.build(sample)"

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::setOptimizationAlgorithm
"Accessor to the solver.

Parameters
----------
solver : :class:`~openturns.OptimizationAlgorithm`
    The solver used for numerical optimization of the likelihood."

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::getOptimizationAlgorithm
"Accessor to the solver.

Returns
-------
solver : :class:`~openturns.OptimizationAlgorithm`
    The solver used for numerical optimization of the likelihood."

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::setOptimizationBounds
"Accessor to the optimization bounds.

Parameters
----------
bounds : :class:`~openturns.Interval`
    The bounds used for numerical optimization of the likelihood."

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::getOptimizationBounds
"Accessor to the optimization bounds.

Returns
-------
bounds : :class:`~openturns.Interval`
    The bounds used for numerical optimization of the likelihood."

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::setOptimizationInequalityConstraint
"Accessor to the optimization inequality constraint.

Parameters
----------
inequalityConstraint : :class:`~openturns.Function`
    The inequality constraint used for numerical optimization of the likelihood."

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::setKnownParameter
"Accessor to the known parameters.

Parameters
----------
values : sequence of float
    Values of fixed parameters.
indices : sequence of int
    Indices of fixed parameters.

Examples
--------
>>> import openturns as ot
>>> ot.RandomGenerator.SetSeed(0)
>>> distribution = ot.Beta(2.3, 2.2, -1.0, 1.0)
>>> sample = distribution.getSample(10)
>>> factory = ot.MaximumLikelihoodFactory(ot.Beta())
>>> # set (a,b) out of (r, t, a, b)
>>> factory.setKnownParameter([-1.0, 1.0], [2, 3])
>>> inf_distribution = factory.build(sample)"

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::getKnownParameterValues
"Accessor to the known parameters indices.

Returns
-------
values : :class:`~openturns.Point`
    Values of fixed parameters."

// ---------------------------------------------------------------------

%feature("docstring") OT::MaximumLikelihoodFactory::getKnownParameterIndices
"Accessor to the known parameters indices.

Returns
-------
indices : :class:`~openturns.Indices`
    Indices of fixed parameters."

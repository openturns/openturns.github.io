#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "OT" for configuration "RelWithDebInfo"
set_property(TARGET OT APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(OT PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "hmat-oss"
  IMPORTED_LOCATION_RELWITHDEBINFO "/usr/lib/libOT.so.0.16.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libOT.so.0.16"
  )

list(APPEND _IMPORT_CHECK_TARGETS OT )
list(APPEND _IMPORT_CHECK_FILES_FOR_OT "/usr/lib/libOT.so.0.16.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
